# Nexus Identify — Project TODO

Legend: [x] done · [ ] to do · [~] in progress
Rule: no real people's images until Phase 1 legal/ethics items are signed off.

## Phase 1 — Research & requirements
- [~] Write project requirements (docs/requirements.md — draft started)
- [ ] Define permitted / prohibited uses (draft in docs/requirements.md)
- [ ] Research Data Protection Act 2012 (Act 843) obligations; contact Data Protection Commission
- [ ] Register / confirm compliance arrangements for Nexus Sync Technologies
- [ ] Privacy impact assessment (biometric processing)
- [ ] Risk register
- [ ] List what an agency needs to approve a pilot

## Phase 2 — Technical foundation
- [x] Repo structure created
- [x] Backend skeleton (FastAPI), config, DB session
- [x] Models: users, cases, case_authorizations, audit_events
- [x] Auth: scrypt password hashing, JWT login, session expiry
- [x] Role-based access (admin, investigator, reviewer, auditor)
- [x] Case management endpoints (create / list / get / approve)
- [x] Audit logging service + audit endpoint (auditor/admin only)
- [x] Docker + docker-compose (Postgres + backend)
- [x] Initial tests (auth, roles, case access, audit)
- [ ] Run the test suite locally and fix anything that fails (NOT yet run)
- [ ] Add Alembic migrations (replace create_all)
- [ ] Account suspension + admin user management endpoints
- [x] Frontend app (Next.js 14 + TypeScript) scaffold, /api proxy to backend
- [x] Login page + dashboard shell (sidebar, role-aware nav)
- [x] Cases page (list, create, admin approve) + Audit log page
- [ ] Run `npm install && npm run dev` and fix any type/build errors (NOT yet run)
- [ ] Move auth token from sessionStorage to httpOnly cookie session
- [ ] Replace window.prompt approval flow with a proper modal form

## Phase 3 — Image handling (weeks 3-4)
- [x] Upload endpoint with type (magic-byte) / size / dimension limits
- [x] Face detection + quality checks (Haar cascade: face count, size, blur, lighting)
- [x] Images re-encoded on upload (strips EXIF/GPS); SHA-256 recorded
- [x] Private encrypted-at-rest storage (Fernet, local disk) + delete endpoints
- [x] Source + permitted use recorded (reference: source; gallery: source + permission_basis + delete_after)
- [x] Retention purge job (`python -m app.retention`) + audit events for upload/view/delete/purge
- [x] Case detail page: upload, quality readout, thumbnails, delete
- [x] Tests: tests/test_images.py (NOT yet run)
- [ ] Run `pip install -r requirements.txt && pytest`; run frontend; fix errors
- [ ] Generate STORAGE_ENCRYPTION_KEY and put in .env (never commit)
- [ ] Gallery admin UI (add image + permission basis + delete date)
- [ ] Schedule retention purge (cron / container scheduler)
- [ ] Calibrate quality thresholds in Phase 6 (current values are placeholders)
- [ ] Known limit: Haar detector is frontal-only; no head-pose or occlusion check yet
- [ ] Key management: move encryption key to a secrets manager; plan key rotation
- [ ] Swap local storage for private object storage in any real deployment

## Phase 4 — Matching prototype (weeks 5-6)
- [x] Model chosen: OpenCV YuNet + SFace (Apache-2.0) behind a swappable FaceEmbedder interface
- [x] docs/model-selection.md written (licence position, caveats, open items)
- [x] scripts/download_models.py (fetches ONNX files, prints SHA-256)
- [x] Gallery upload now embeds each image; images with no usable face are rejected
- [x] Embeddings stored encrypted, tagged with model_version, deleted with the gallery record / on retention purge
- [x] Search endpoint: ranked candidates above threshold, explicit "no_match" outcome, model + threshold + gallery size recorded
- [x] Reference embedding computed in memory only, never stored
- [x] Candidate image viewing audited; auditors cannot see faces
- [x] Results UI on case page (scores, source, "awaiting human review", no-match message)
- [x] Tests: test_matching.py, test_similarity.py (use a fake embedder; NOT yet run)
- [ ] Run `python scripts/download_models.py`, record SHA-256s in docs/model-selection.md
- [ ] Try real synthetic/consented faces end to end (the fake embedder only tests the plumbing)
- [ ] LEGAL: confirm SFace training-data provenance / licence suitability for a government pilot
- [ ] Threshold 0.363 is NOT validated; set it from Phase 6 measurements
- [ ] Consider pgvector only after a threat model for encrypted vectors

## Phase 5 — Investigation dashboard (weeks 7-8)
- [x] Review queue (pending candidates; excludes ones you ran yourself)
- [x] Decisions: confirmed / rejected / inconclusive + required written reason; history kept; latest wins
- [x] Independent review rule (searcher cannot review); needs unexpired approval; "not an identification" warning
- [x] Case notes (investigator, reviewer, admin)
- [x] Case report endpoint + printable report page (no images/biometrics) + audit of report generation
- [x] Dashboard stats (cases, searches, awaiting review, decisions)
- [x] Review queue page with reference vs candidate side by side
- [x] docs/review-procedure.md (draft for agency)
- [x] Tests: tests/test_reviews.py (NOT yet run)
- [ ] Run backend tests + frontend; fix errors
- [x] User management: list, create, change role, suspend/reactivate, reset password (admin can't demote/suspend self) + Users page
- [x] Gallery admin page (add with permission basis + delete-by date, view, delete; admin image views audited)
- [x] Case close (owner/admin) / reopen (admin) + retention change (admin, future dates only, audited); closed cases are locked
- [ ] Define correction / appeals procedure with the agency
- [x] Approval modal (replaced window.prompt)
- [x] Tests: tests/test_admin.py (NOT yet run)
- [ ] Force password change on first login (admin-set passwords are temporary)
- [ ] Rate-limit / lock out repeated failed logins

## Phase 6 — Validation & security (weeks 9-10)
- [ ] Genuine / non-match / difficult-image tests; FPR & FNR
- [ ] Demographic performance testing
- [ ] Authorization, retention, deletion tests
- [ ] Test report + known limitations

## Phase 7 — Institutional review (weeks 11-12)
- [ ] Live demo on synthetic/authorized data
- [ ] Architecture + security overview
- [ ] Pilot plan, budget, partnership proposal

## Phase 8 — Approved pilot planning
- [ ] Agreed data sources, approvals, metrics, oversight, stop conditions

## Parking lot (NOT in v1)
- Screen-based / social media analysis (only within an expressly authorized workflow)
- Government database integrations
- Multi-agency deployments
