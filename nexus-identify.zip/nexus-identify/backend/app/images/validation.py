"""Image validation, sanitising and quality assessment.

Face detection here uses OpenCV's bundled Haar cascade: dependency-free and fine for a
prototype gate, but it only finds frontal faces and does NOT assess head angle or occlusion.
Thresholds below are placeholders to be calibrated during Phase 6 testing.
"""
import hashlib
import struct
from dataclasses import asdict, dataclass
from functools import lru_cache

import cv2
import numpy as np

from ..config import settings

MIN_SIDE_PX = 200
MIN_FACE_PX = 80
MIN_BLUR_SCORE = 60.0          # variance of Laplacian on the face crop
BRIGHTNESS_RANGE = (40.0, 220.0)


class ImageRejected(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


@dataclass
class QualityReport:
    usable: bool
    reasons: list[str]
    metrics: dict

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ProcessedImage:
    data: bytes          # re-encoded, metadata-stripped bytes
    ext: str
    content_type: str
    sha256: str
    report: QualityReport


def sniff_type(data: bytes) -> tuple[str, str]:
    """Identify the type from magic bytes; never trust the filename or client content-type."""
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg", ".jpg"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png", ".png"
    raise ImageRejected("unsupported_type", "Only JPEG and PNG images are accepted")


def read_dimensions(data: bytes, content_type: str) -> tuple[int, int]:
    """Read width/height from the header so huge images are refused before full decoding."""
    try:
        if content_type == "image/png":
            w, h = struct.unpack(">II", data[16:24])
            return w, h
        i = 2
        while i + 9 < len(data):
            if data[i] != 0xFF:
                i += 1
                continue
            marker = data[i + 1]
            if marker == 0xFF:
                i += 1
                continue
            if marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:
                i += 2
                continue
            seg_len = struct.unpack(">H", data[i + 2:i + 4])[0]
            if 0xC0 <= marker <= 0xCF and marker not in (0xC4, 0xC8, 0xCC):
                h, w = struct.unpack(">HH", data[i + 5:i + 9])
                return w, h
            i += 2 + seg_len
    except struct.error:
        pass
    raise ImageRejected("corrupt", "Could not read image dimensions")


@lru_cache(maxsize=1)
def _cascade() -> "cv2.CascadeClassifier":
    c = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    if c.empty():
        raise RuntimeError("Could not load OpenCV face cascade")
    return c


def analyze(img: np.ndarray) -> QualityReport:
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = _cascade().detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40))
    brightness = round(float(gray.mean()), 1)
    metrics: dict = {"width": int(img.shape[1]), "height": int(img.shape[0]),
                     "faces_detected": int(len(faces)), "brightness": brightness}
    reasons: list[str] = []

    if len(faces) == 0:
        reasons.append("no_face_detected")
    elif len(faces) > 1:
        reasons.append("multiple_faces")
    else:
        x, y, w, h = (int(v) for v in faces[0])
        blur = float(cv2.Laplacian(gray[y:y + h, x:x + w], cv2.CV_64F).var())
        metrics.update(face_px=w, blur_score=round(blur, 1))
        if w < MIN_FACE_PX:
            reasons.append("face_too_small")
        if blur < MIN_BLUR_SCORE:
            reasons.append("image_too_blurry")

    if not (BRIGHTNESS_RANGE[0] <= brightness <= BRIGHTNESS_RANGE[1]):
        reasons.append("poor_lighting")
    return QualityReport(usable=not reasons, reasons=reasons, metrics=metrics)


def process_upload(data: bytes) -> ProcessedImage:
    if not data:
        raise ImageRejected("empty", "Empty file")
    content_type, ext = sniff_type(data)
    w, h = read_dimensions(data, content_type)
    if w * h > settings.max_image_pixels:
        raise ImageRejected("too_large_dimensions", "Image dimensions are too large")
    if min(w, h) < MIN_SIDE_PX:
        raise ImageRejected("too_small_dimensions", f"Image must be at least {MIN_SIDE_PX}px on each side")

    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise ImageRejected("corrupt", "Image could not be decoded")

    report = analyze(img)
    # Re-encode: strips EXIF/GPS and any appended payload from the stored copy.
    params = [cv2.IMWRITE_JPEG_QUALITY, 95] if ext == ".jpg" else []
    ok, buf = cv2.imencode(ext, img, params)
    if not ok:
        raise ImageRejected("corrupt", "Image could not be re-encoded")
    clean = buf.tobytes()
    return ProcessedImage(clean, ext, content_type, hashlib.sha256(clean).hexdigest(), report)
