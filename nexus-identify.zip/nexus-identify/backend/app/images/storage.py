"""Private, encrypted-at-rest image storage (local disk for the prototype).

Swap for an S3-compatible private bucket with server-side encryption in a real deployment.
"""
import os
import uuid
from functools import lru_cache
from pathlib import Path

from cryptography.fernet import Fernet

from ..config import settings


class EncryptedLocalStorage:
    def __init__(self, root: str | Path, key: str):
        if not key:
            raise RuntimeError(
                "STORAGE_ENCRYPTION_KEY is not set. Generate one with: "
                'python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"'
            )
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self._fernet = Fernet(key.encode() if isinstance(key, str) else key)

    def seal(self, data: bytes) -> bytes:
        """Encrypt arbitrary bytes (used for embeddings stored in the database)."""
        return self._fernet.encrypt(data)

    def unseal(self, blob: bytes) -> bytes:
        return self._fernet.decrypt(blob)

    def _path(self, key: str) -> Path:
        p = (self.root / key).resolve()
        if self.root not in p.parents:
            raise ValueError("Invalid storage key")
        return p

    def save(self, data: bytes, prefix: str, ext: str) -> str:
        key = f"{prefix}/{uuid.uuid4().hex}{ext}"
        path = self._path(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(self._fernet.encrypt(data))
        os.replace(tmp, path)
        return key

    def read(self, key: str) -> bytes:
        return self._fernet.decrypt(self._path(key).read_bytes())

    def delete(self, key: str) -> bool:
        if not key:
            return False
        path = self._path(key)
        if path.exists():
            path.unlink()
            return True
        return False


@lru_cache
def get_storage() -> EncryptedLocalStorage:
    return EncryptedLocalStorage(settings.storage_dir, settings.storage_encryption_key)
