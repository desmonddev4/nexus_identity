from datetime import datetime, timezone

from fastapi import APIRouter, Depends, File, Form, HTTPException, Response, UploadFile, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..audit.service import record
from ..auth.deps import require_roles
from ..config import settings
from ..db import get_db
from ..matching.deps import get_embedder
from ..matching.embedder import FaceEmbedder
from ..matching.service import delete_embeddings, embed_or_reject
from ..models import Case, CaseStatus, Embedding, GalleryRecord, ReferenceImage, Role, User, utcnow
from .storage import EncryptedLocalStorage, get_storage
from .validation import ImageRejected, ProcessedImage, process_upload

router = APIRouter(tags=["images"])

WRITE_ROLES = (Role.investigator, Role.admin)
READ_ROLES = (Role.investigator, Role.admin, Role.reviewer)   # auditors see logs, not faces


class ReferenceOut(BaseModel):
    id: int
    case_id: int
    source: str
    sha256: str
    quality: dict
    status: str
    created_at: datetime
    model_config = {"from_attributes": True}


class GalleryOut(BaseModel):
    id: int
    source: str
    permission_basis: str
    sha256: str
    quality: dict
    status: str
    collected_at: datetime
    delete_after: datetime
    model_config = {"from_attributes": True}


def _aware(dt: datetime) -> datetime:
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _case_for(db: Session, case_id: int, user: User, write: bool) -> Case:
    case = db.get(Case, case_id)
    allowed = case is not None and (
        user.role == Role.admin
        or case.owner_id == user.id
        or (not write and user.role == Role.reviewer)
    )
    if not allowed:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Case not found")
    return case


def _require_active_authorization(case: Case) -> None:
    now = datetime.now(timezone.utc)
    ok = case.status == CaseStatus.approved and any(_aware(a.expires_at) > now for a in case.authorizations)
    if not ok:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Case has no active approval")


async def _read_limited(file: UploadFile) -> bytes:
    data = await file.read(settings.max_image_bytes + 1)
    if len(data) > settings.max_image_bytes:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "Image too large")
    return data


def _process(db: Session, data: bytes, user: User, case_id: int | None) -> ProcessedImage:
    try:
        processed = process_upload(data)
    except ImageRejected as e:
        record(db, "image_rejected", actor_id=user.id, case_id=case_id, detail=e.code)
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    if not processed.report.usable:
        record(db, "image_rejected", actor_id=user.id, case_id=case_id,
               detail=",".join(processed.report.reasons))
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                            {"reasons": processed.report.reasons, "metrics": processed.report.metrics})
    return processed


def _media_type(key: str) -> str:
    return "image/png" if key.endswith(".png") else "image/jpeg"


# ---------------- reference images (per case) ----------------

@router.post("/cases/{case_id}/reference-images", response_model=ReferenceOut, status_code=201)
async def upload_reference(case_id: int, source: str = Form(...), file: UploadFile = File(...),
                           db: Session = Depends(get_db),
                           user: User = Depends(require_roles(*WRITE_ROLES)),
                           storage: EncryptedLocalStorage = Depends(get_storage)):
    case = _case_for(db, case_id, user, write=True)
    _require_active_authorization(case)
    if not source.strip():
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Image source is required")
    processed = _process(db, await _read_limited(file), user, case.id)
    key = storage.save(processed.data, f"reference/{case.id}", processed.ext)
    row = ReferenceImage(case_id=case.id, storage_key=key, source=source.strip(),
                         sha256=processed.sha256, quality=processed.report.to_dict(),
                         uploaded_by=user.id)
    db.add(row)
    db.commit()
    db.refresh(row)
    record(db, "reference_image_uploaded", actor_id=user.id, case_id=case.id,
           detail=f"image_id={row.id} sha256={row.sha256[:12]}")
    return row


@router.get("/cases/{case_id}/reference-images", response_model=list[ReferenceOut])
def list_reference(case_id: int, db: Session = Depends(get_db),
                   user: User = Depends(require_roles(*READ_ROLES))):
    case = _case_for(db, case_id, user, write=False)
    q = select(ReferenceImage).where(ReferenceImage.case_id == case.id, ReferenceImage.status == "active")
    return db.scalars(q.order_by(ReferenceImage.id)).all()


def _active_reference(db: Session, image_id: int, user: User, write: bool) -> ReferenceImage:
    row = db.get(ReferenceImage, image_id)
    if not row or row.status != "active":
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Image not found")
    _case_for(db, row.case_id, user, write=write)   # same access rule as the case
    return row


@router.get("/reference-images/{image_id}/file")
def reference_file(image_id: int, db: Session = Depends(get_db),
                   user: User = Depends(require_roles(*READ_ROLES)),
                   storage: EncryptedLocalStorage = Depends(get_storage)):
    row = _active_reference(db, image_id, user, write=False)
    record(db, "reference_image_viewed", actor_id=user.id, case_id=row.case_id, detail=f"image_id={row.id}")
    return Response(storage.read(row.storage_key), media_type=_media_type(row.storage_key),
                    headers={"Cache-Control": "no-store"})


@router.delete("/reference-images/{image_id}")
def delete_reference(image_id: int, db: Session = Depends(get_db),
                     user: User = Depends(require_roles(*WRITE_ROLES)),
                     storage: EncryptedLocalStorage = Depends(get_storage)):
    row = _active_reference(db, image_id, user, write=True)
    storage.delete(row.storage_key)
    row.storage_key, row.status, row.deleted_at = "", "deleted", utcnow()
    db.commit()
    record(db, "reference_image_deleted", actor_id=user.id, case_id=row.case_id, detail=f"image_id={row.id}")
    return {"ok": True}


# ---------------- authorized gallery (admin only) ----------------

@router.post("/gallery", response_model=GalleryOut, status_code=201)
async def add_gallery_image(source: str = Form(...), permission_basis: str = Form(...),
                            delete_after: datetime = Form(...), file: UploadFile = File(...),
                            db: Session = Depends(get_db),
                            admin: User = Depends(require_roles(Role.admin)),
                            storage: EncryptedLocalStorage = Depends(get_storage),
                            embedder: FaceEmbedder = Depends(get_embedder)):
    if not source.strip() or not permission_basis.strip():
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Source and permission basis are required")
    if _aware(delete_after) <= datetime.now(timezone.utc):
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "delete_after must be in the future")
    processed = _process(db, await _read_limited(file), admin, None)
    vec = embed_or_reject(db, embedder, processed.data, admin, None)   # reject before storing anything
    key = storage.save(processed.data, "gallery", processed.ext)
    row = GalleryRecord(source=source.strip(), permission_basis=permission_basis.strip(),
                        storage_key=key, sha256=processed.sha256, quality=processed.report.to_dict(),
                        delete_after=delete_after, added_by=admin.id)
    db.add(row)
    db.flush()
    db.add(Embedding(gallery_record_id=row.id, model_version=embedder.model_version,
                     blob=storage.seal(vec.astype("float32").tobytes())))
    db.commit()
    db.refresh(row)
    record(db, "gallery_image_added", actor_id=admin.id, detail=f"gallery_id={row.id}")
    return row


@router.get("/gallery", response_model=list[GalleryOut])
def list_gallery(db: Session = Depends(get_db), _: User = Depends(require_roles(Role.admin))):
    q = select(GalleryRecord).where(GalleryRecord.status == "active").order_by(GalleryRecord.id)
    return db.scalars(q).all()


@router.get("/gallery/{gallery_id}/image")
def gallery_image(gallery_id: int, db: Session = Depends(get_db),
                  admin: User = Depends(require_roles(Role.admin)),
                  storage: EncryptedLocalStorage = Depends(get_storage)):
    row = db.get(GalleryRecord, gallery_id)
    if not row or row.status != "active":
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Gallery record not found")
    record(db, "gallery_image_viewed", actor_id=admin.id, detail=f"gallery_id={row.id}")
    return Response(storage.read(row.storage_key), media_type=_media_type(row.storage_key),
                    headers={"Cache-Control": "no-store"})


@router.delete("/gallery/{gallery_id}")
def delete_gallery_image(gallery_id: int, db: Session = Depends(get_db),
                         admin: User = Depends(require_roles(Role.admin)),
                         storage: EncryptedLocalStorage = Depends(get_storage)):
    row = db.get(GalleryRecord, gallery_id)
    if not row or row.status != "active":
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Gallery record not found")
    storage.delete(row.storage_key)
    delete_embeddings(db, row.id)
    row.storage_key, row.status, row.deleted_at = "", "deleted", utcnow()
    db.commit()
    record(db, "gallery_image_deleted", actor_id=admin.id, detail=f"gallery_id={row.id}")
    return {"ok": True}
