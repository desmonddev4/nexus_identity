from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..audit.service import record
from ..db import get_db
from ..models import Role, User, UserStatus
from .deps import current_user, require_roles
from .security import create_token, hash_password, verify_password

router = APIRouter(prefix="/auth", tags=["auth"])


class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str = Field(min_length=8)
    role: Role


class UserOut(BaseModel):
    id: int
    name: str
    email: str
    role: Role
    status: UserStatus
    model_config = {"from_attributes": True}


@router.post("/login")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == form.username))
    if not user or not verify_password(form.password, user.password_hash) \
            or user.status != UserStatus.active:
        record(db, "login_failed", detail=form.username)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect email or password")
    record(db, "login", actor_id=user.id)
    return {"access_token": create_token(user.id), "token_type": "bearer"}


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return user


@router.post("/users", response_model=UserOut, status_code=201)
def create_user(body: UserCreate, db: Session = Depends(get_db),
                admin: User = Depends(require_roles(Role.admin))):
    if db.scalar(select(User).where(User.email == body.email)):
        raise HTTPException(status.HTTP_409_CONFLICT, "Email already registered")
    user = User(name=body.name, email=body.email,
                password_hash=hash_password(body.password), role=body.role)
    db.add(user)
    db.commit()
    db.refresh(user)
    record(db, "user_created", actor_id=admin.id, detail=f"user_id={user.id} role={user.role.value}")
    return user


class UserUpdate(BaseModel):
    role: Role | None = None
    status: UserStatus | None = None
    password: str | None = Field(default=None, min_length=8)


@router.get("/users", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db), _: User = Depends(require_roles(Role.admin))):
    return db.scalars(select(User).order_by(User.id)).all()


@router.patch("/users/{user_id}", response_model=UserOut)
def update_user(user_id: int, body: UserUpdate, db: Session = Depends(get_db),
                admin: User = Depends(require_roles(Role.admin))):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "User not found")
    if user.id == admin.id and ((body.role and body.role != user.role)
                                or (body.status and body.status != UserStatus.active)):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "You cannot change your own role or suspend yourself")
    changes = []
    if body.role and body.role != user.role:
        changes.append(f"role {user.role.value}->{body.role.value}")
        user.role = body.role
    if body.status and body.status != user.status:
        changes.append(f"status {user.status.value}->{body.status.value}")
        user.status = body.status
    if body.password:
        user.password_hash = hash_password(body.password)
        changes.append("password_reset")
    db.commit()
    db.refresh(user)
    if changes:
        record(db, "user_updated", actor_id=admin.id, detail=f"user_id={user.id} " + ", ".join(changes))
    return user
