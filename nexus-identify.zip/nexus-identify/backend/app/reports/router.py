from collections import Counter
from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..audit.service import record
from ..auth.deps import current_user, require_roles
from ..db import get_db
from ..models import (AuditEvent, Candidate, Case, CaseAuthorization, CaseNote, ReferenceImage,
                      ReviewDecision, Role, SearchJob, User)
from ..reviews.router import visible_case

router = APIRouter(tags=["reports"])

DISCLAIMER = ("This report summarises a prototype's possible-match results and the human decisions made on them. "
              "Similarity scores are not probabilities of identity. No candidate is an identification, and "
              "nothing here is grounds for arrest, accusation or adverse action without independent verification. "
              "Contains no images or biometric data.")


@router.get("/stats")
def stats(db: Session = Depends(get_db), user: User = Depends(current_user)):
    q = select(Case)
    if user.role == Role.investigator:
        q = q.where(Case.owner_id == user.id)
    cases = db.scalars(q).all()
    ids = [c.id for c in cases]
    by_status = dict(Counter(c.status.value for c in cases))
    if not ids:
        return {"cases": by_status, "searches": 0, "pending_review": 0, "decisions": {}}
    searches = db.scalar(select(func.count()).select_from(SearchJob).where(SearchJob.case_id.in_(ids))) or 0
    rows = db.execute(
        select(Candidate.review_status, func.count())
        .join(SearchJob, SearchJob.id == Candidate.search_job_id)
        .where(SearchJob.case_id.in_(ids)).group_by(Candidate.review_status)
    ).all()
    counts = {k: v for k, v in rows}
    pending = counts.pop("pending", 0)
    return {"cases": by_status, "searches": searches, "pending_review": pending, "decisions": counts}


@router.get("/cases/{case_id}/report")
def case_report(case_id: int, db: Session = Depends(get_db),
                user: User = Depends(require_roles(Role.admin, Role.investigator, Role.reviewer, Role.auditor))):
    case = visible_case(db, case_id, user)
    names: dict[int, str] = {}

    def name(uid: int | None) -> str:
        if uid is None:
            return "system"
        if uid not in names:
            u = db.get(User, uid)
            names[uid] = u.name if u else f"user {uid}"
        return names[uid]

    auths = db.scalars(select(CaseAuthorization).where(CaseAuthorization.case_id == case.id)).all()
    ref_count = db.scalar(select(func.count()).select_from(ReferenceImage)
                          .where(ReferenceImage.case_id == case.id)) or 0
    jobs = db.scalars(select(SearchJob).where(SearchJob.case_id == case.id).order_by(SearchJob.id)).all()
    searches = []
    for j in jobs:
        cands = []
        for c in j.candidates:
            decs = db.scalars(select(ReviewDecision).where(ReviewDecision.candidate_id == c.id)
                              .order_by(ReviewDecision.id)).all()
            cands.append({"rank": c.rank, "score": round(c.score, 4), "source": c.gallery_record.source,
                          "review_status": c.review_status,
                          "decisions": [{"reviewer": name(d.reviewer_id), "decision": d.decision,
                                         "reason": d.reason, "at": d.created_at} for d in decs]})
        searches.append({"id": j.id, "created_at": j.created_at, "requested_by": name(j.requested_by),
                         "outcome": j.outcome, "model_version": j.model_version, "threshold": j.threshold,
                         "gallery_size": j.gallery_size, "candidates": cands})
    notes = db.scalars(select(CaseNote).where(CaseNote.case_id == case.id).order_by(CaseNote.id)).all()
    events = db.scalars(select(AuditEvent).where(AuditEvent.case_id == case.id).order_by(AuditEvent.id)).all()

    record(db, "report_generated", actor_id=user.id, case_id=case.id)
    return {
        "generated_at": datetime.now(timezone.utc), "generated_by": user.name,
        "case": {"case_ref": case.case_ref, "purpose": case.purpose, "status": case.status.value,
                 "owner": name(case.owner_id), "retention_date": case.retention_date, "created_at": case.created_at},
        "authorizations": [{"approved_by": name(a.approved_by), "scope": a.scope, "expires_at": a.expires_at}
                           for a in auths],
        "reference_images": ref_count,
        "searches": searches,
        "notes": [{"author": name(n.author_id), "body": n.body, "created_at": n.created_at} for n in notes],
        "audit": [{"timestamp": e.timestamp, "action": e.action, "actor": name(e.actor_id), "detail": e.detail}
                  for e in events],
        "disclaimer": DISCLAIMER,
    }
