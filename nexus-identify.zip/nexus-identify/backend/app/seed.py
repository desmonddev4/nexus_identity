"""Create the first admin: python -m app.seed admin@example.com 'Name' 'password'"""
import sys

from .auth.security import hash_password
from .db import Base, SessionLocal, engine
from .models import Role, User

if __name__ == "__main__":
    email, name, password = sys.argv[1:4]
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        db.add(User(email=email, name=name, role=Role.admin, password_hash=hash_password(password)))
        db.commit()
    print("Admin created.")
