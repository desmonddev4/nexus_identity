from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "sqlite:///./dev.db"
    secret_key: str = "dev-only-change-me"
    access_token_minutes: int = 30
    jwt_algorithm: str = "HS256"

    # Image handling (Phase 3)
    storage_dir: str = "./storage"
    storage_encryption_key: str = ""      # required for any image upload; see .env.example
    max_image_bytes: int = 5_000_000
    max_image_pixels: int = 25_000_000

    # Matching (Phase 4)
    matching_model_dir: str = "./models"
    match_threshold: float = 0.363   # cosine; OpenCV SFace demo value, NOT validated on our data
    max_candidates: int = 10

    class Config:
        env_file = ".env"


settings = Settings()
