"""Delete images past their retention date. Run on a schedule: python -m app.retention"""
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from .audit.service import record
from .images.storage import EncryptedLocalStorage
from .matching.service import delete_embeddings
from .models import Case, GalleryRecord, ReferenceImage, utcnow


def purge_expired(db: Session, storage: EncryptedLocalStorage, now: datetime | None = None) -> dict:
    now = now or datetime.now(timezone.utc)
    counts = {"reference": 0, "gallery": 0}

    refs = db.scalars(
        select(ReferenceImage).join(Case, Case.id == ReferenceImage.case_id)
        .where(ReferenceImage.status == "active", Case.retention_date <= now)
    ).all()
    for r in refs:
        storage.delete(r.storage_key)
        r.storage_key, r.status, r.deleted_at = "", "deleted", utcnow()
        counts["reference"] += 1

    gallery = db.scalars(
        select(GalleryRecord).where(GalleryRecord.status == "active", GalleryRecord.delete_after <= now)
    ).all()
    for g in gallery:
        storage.delete(g.storage_key)
        delete_embeddings(db, g.id)
        g.storage_key, g.status, g.deleted_at = "", "deleted", utcnow()
        counts["gallery"] += 1

    db.commit()
    if counts["reference"] or counts["gallery"]:
        record(db, "retention_purge", detail=f"reference={counts['reference']} gallery={counts['gallery']}")
    return counts


if __name__ == "__main__":
    from .db import SessionLocal
    from .images.storage import get_storage

    with SessionLocal() as session:
        print(purge_expired(session, get_storage()))
