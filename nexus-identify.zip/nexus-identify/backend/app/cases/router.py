from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..audit.service import record
from ..auth.deps import current_user, require_roles
from ..db import get_db
from ..models import Case, CaseAuthorization, CaseStatus, Role, User

router = APIRouter(prefix="/cases", tags=["cases"])


class CaseCreate(BaseModel):
    case_ref: str
    purpose: str
    retention_date: datetime


class ApproveBody(BaseModel):
    scope: str
    expires_at: datetime


class CaseOut(BaseModel):
    id: int
    case_ref: str
    purpose: str
    status: CaseStatus
    owner_id: int
    retention_date: datetime
    model_config = {"from_attributes": True}


def _can_view(user: User, case: Case) -> bool:
    return user.role in (Role.admin, Role.auditor, Role.reviewer) or case.owner_id == user.id


@router.post("", response_model=CaseOut, status_code=201)
def create_case(body: CaseCreate, db: Session = Depends(get_db),
                user: User = Depends(require_roles(Role.investigator, Role.admin))):
    if not body.purpose.strip():
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Purpose is required")
    if db.scalar(select(Case).where(Case.case_ref == body.case_ref)):
        raise HTTPException(status.HTTP_409_CONFLICT, "Case reference already exists")
    case = Case(case_ref=body.case_ref, purpose=body.purpose, owner_id=user.id,
                retention_date=body.retention_date)
    db.add(case)
    db.commit()
    db.refresh(case)
    record(db, "case_created", actor_id=user.id, case_id=case.id)
    return case


@router.get("", response_model=list[CaseOut])
def list_cases(db: Session = Depends(get_db), user: User = Depends(current_user)):
    q = select(Case)
    if user.role == Role.investigator:
        q = q.where(Case.owner_id == user.id)
    return db.scalars(q.order_by(Case.id.desc())).all()


@router.get("/{case_id}", response_model=CaseOut)
def get_case(case_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    case = db.get(Case, case_id)
    if not case or not _can_view(user, case):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Case not found")
    record(db, "case_viewed", actor_id=user.id, case_id=case.id)
    return case


@router.post("/{case_id}/approve", response_model=CaseOut)
def approve_case(case_id: int, body: ApproveBody, db: Session = Depends(get_db),
                 admin: User = Depends(require_roles(Role.admin))):
    case = db.get(Case, case_id)
    if not case:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Case not found")
    if body.expires_at <= datetime.now(timezone.utc):
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Expiry must be in the future")
    db.add(CaseAuthorization(case_id=case.id, approved_by=admin.id,
                             scope=body.scope, expires_at=body.expires_at))
    case.status = CaseStatus.approved
    db.commit()
    db.refresh(case)
    record(db, "case_approved", actor_id=admin.id, case_id=case.id, detail=body.scope)
    return case


class RetentionBody(BaseModel):
    retention_date: datetime


def _aware(dt: datetime) -> datetime:
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


@router.post("/{case_id}/close", response_model=CaseOut)
def close_case(case_id: int, db: Session = Depends(get_db),
               user: User = Depends(require_roles(Role.investigator, Role.admin))):
    case = db.get(Case, case_id)
    if not case or not (user.role == Role.admin or case.owner_id == user.id):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Case not found")
    if case.status == CaseStatus.closed:
        raise HTTPException(status.HTTP_409_CONFLICT, "Case is already closed")
    case.status = CaseStatus.closed
    db.commit()
    db.refresh(case)
    record(db, "case_closed", actor_id=user.id, case_id=case.id)
    return case


@router.post("/{case_id}/reopen", response_model=CaseOut)
def reopen_case(case_id: int, db: Session = Depends(get_db),
                admin: User = Depends(require_roles(Role.admin))):
    case = db.get(Case, case_id)
    if not case:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Case not found")
    if case.status != CaseStatus.closed:
        raise HTTPException(status.HTTP_409_CONFLICT, "Only closed cases can be reopened")
    now = datetime.now(timezone.utc)
    active = any(_aware(a.expires_at) > now for a in case.authorizations)
    case.status = CaseStatus.approved if active else CaseStatus.pending_approval
    db.commit()
    db.refresh(case)
    record(db, "case_reopened", actor_id=admin.id, case_id=case.id, detail=f"status={case.status.value}")
    return case


@router.post("/{case_id}/retention", response_model=CaseOut)
def set_retention(case_id: int, body: RetentionBody, db: Session = Depends(get_db),
                  admin: User = Depends(require_roles(Role.admin))):
    case = db.get(Case, case_id)
    if not case:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Case not found")
    if _aware(body.retention_date) <= datetime.now(timezone.utc):
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                            "Retention date must be in the future (delete images directly to remove them sooner)")
    old = case.retention_date
    case.retention_date = body.retention_date
    db.commit()
    db.refresh(case)
    record(db, "case_retention_updated", actor_id=admin.id, case_id=case.id,
           detail=f"{old.date().isoformat()} -> {body.retention_date.date().isoformat()}")
    return case
