from contextlib import asynccontextmanager

from fastapi import FastAPI

from .audit.router import router as audit_router
from .auth.router import router as auth_router
from .cases.router import router as cases_router
from .db import Base, engine
from .images.router import router as images_router
from .matching.router import router as matching_router
from .reports.router import router as reports_router
from .reviews.router import router as reviews_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)  # TODO: replace with Alembic migrations
    yield


app = FastAPI(title="Nexus Identify API", version="0.1.0", lifespan=lifespan)
app.include_router(auth_router)
app.include_router(cases_router)
app.include_router(audit_router)
app.include_router(images_router)
app.include_router(matching_router)
app.include_router(reviews_router)
app.include_router(reports_router)


@app.get("/health")
def health():
    return {"status": "ok"}
