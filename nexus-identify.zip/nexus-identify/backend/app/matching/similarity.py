"""Pure similarity ranking (no I/O). Vectors must be L2-normalised, so dot product == cosine."""
import numpy as np


def rank_candidates(query: np.ndarray, matrix: np.ndarray, ids: list[int],
                    threshold: float, limit: int) -> list[tuple[int, float]]:
    """Return up to `limit` (id, score) pairs with score >= threshold, best first.

    An empty list is a valid and expected outcome ("no match"); nothing is ever forced.
    """
    if matrix.size == 0 or not ids:
        return []
    q = query / (np.linalg.norm(query) or 1.0)
    scores = matrix @ q
    out: list[tuple[int, float]] = []
    for i in np.argsort(-scores):
        if scores[i] < threshold or len(out) >= limit:
            break
        out.append((ids[int(i)], float(scores[i])))
    return out
