from datetime import datetime, timezone

import numpy as np
from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..audit.service import record
from ..auth.deps import require_roles
from ..config import settings
from ..db import get_db
from ..images.router import READ_ROLES, WRITE_ROLES, _case_for, _require_active_authorization
from ..images.storage import EncryptedLocalStorage, get_storage
from ..models import Candidate, Embedding, GalleryRecord, ReferenceImage, SearchJob, User
from .deps import get_embedder
from .embedder import FaceEmbedder
from .service import embed_or_reject
from .similarity import rank_candidates

router = APIRouter(tags=["matching"])

NOTICE = ("Similarity scores are not probabilities of identity. Candidates are possible matches only "
          "and require independent human review. Never act on a score alone.")


class SearchRequest(BaseModel):
    reference_image_id: int


class CandidateOut(BaseModel):
    id: int
    rank: int
    gallery_record_id: int
    score: float
    source: str
    review_status: str


class SearchOut(BaseModel):
    id: int
    case_id: int
    reference_image_id: int
    outcome: str
    model_version: str
    threshold: float
    gallery_size: int
    created_at: datetime
    candidates: list[CandidateOut]
    notice: str


def _out(job: SearchJob) -> SearchOut:
    return SearchOut(
        id=job.id, case_id=job.case_id, reference_image_id=job.reference_image_id,
        outcome=job.outcome, model_version=job.model_version, threshold=job.threshold,
        gallery_size=job.gallery_size, created_at=job.created_at, notice=NOTICE,
        candidates=[CandidateOut(id=c.id, rank=c.rank, gallery_record_id=c.gallery_record_id,
                                 score=round(c.score, 4), source=c.gallery_record.source,
                                 review_status=c.review_status) for c in job.candidates],
    )


@router.post("/cases/{case_id}/searches", response_model=SearchOut, status_code=201)
def run_search(case_id: int, body: SearchRequest, db: Session = Depends(get_db),
               user: User = Depends(require_roles(*WRITE_ROLES)),
               storage: EncryptedLocalStorage = Depends(get_storage),
               embedder: FaceEmbedder = Depends(get_embedder)):
    case = _case_for(db, case_id, user, write=True)
    _require_active_authorization(case)
    ref = db.get(ReferenceImage, body.reference_image_id)
    if not ref or ref.status != "active" or ref.case_id != case.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Reference image not found")

    # The reference embedding is computed in memory and never stored.
    query = embed_or_reject(db, embedder, storage.read(ref.storage_key), user, case.id)

    now = datetime.now(timezone.utc)
    rows = db.execute(
        select(Embedding.gallery_record_id, Embedding.blob)
        .join(GalleryRecord, GalleryRecord.id == Embedding.gallery_record_id)
        .where(GalleryRecord.status == "active", GalleryRecord.delete_after > now,
               Embedding.model_version == embedder.model_version)
    ).all()
    ids = [r[0] for r in rows]
    matrix = (np.vstack([np.frombuffer(storage.unseal(r[1]), dtype=np.float32) for r in rows])
              if rows else np.empty((0, query.shape[0]), dtype=np.float32))

    hits = rank_candidates(query, matrix, ids, settings.match_threshold, settings.max_candidates)
    job = SearchJob(case_id=case.id, reference_image_id=ref.id, requested_by=user.id,
                    outcome="candidates" if hits else "no_match", model_version=embedder.model_version,
                    threshold=settings.match_threshold, gallery_size=len(ids))
    db.add(job)
    db.flush()
    for rank, (gid, score) in enumerate(hits, start=1):
        db.add(Candidate(search_job_id=job.id, gallery_record_id=gid, rank=rank, score=score))
    db.commit()
    db.refresh(job)
    record(db, "search_run", actor_id=user.id, case_id=case.id,
           detail=f"search_id={job.id} gallery_size={len(ids)} candidates={len(hits)}")
    return _out(job)


@router.get("/cases/{case_id}/searches", response_model=list[SearchOut])
def list_searches(case_id: int, db: Session = Depends(get_db),
                  user: User = Depends(require_roles(*READ_ROLES))):
    case = _case_for(db, case_id, user, write=False)
    jobs = db.scalars(select(SearchJob).where(SearchJob.case_id == case.id).order_by(SearchJob.id.desc())).all()
    return [_out(j) for j in jobs]


@router.get("/searches/{search_id}", response_model=SearchOut)
def get_search(search_id: int, db: Session = Depends(get_db),
               user: User = Depends(require_roles(*READ_ROLES))):
    job = db.get(SearchJob, search_id)
    if not job:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Search not found")
    _case_for(db, job.case_id, user, write=False)
    record(db, "search_viewed", actor_id=user.id, case_id=job.case_id, detail=f"search_id={job.id}")
    return _out(job)


@router.get("/candidates/{candidate_id}/image")
def candidate_image(candidate_id: int, db: Session = Depends(get_db),
                    user: User = Depends(require_roles(*READ_ROLES)),
                    storage: EncryptedLocalStorage = Depends(get_storage)):
    cand = db.get(Candidate, candidate_id)
    job = db.get(SearchJob, cand.search_job_id) if cand else None
    if not cand or not job:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Candidate not found")
    _case_for(db, job.case_id, user, write=False)
    g = cand.gallery_record
    if g.status != "active":
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Gallery image no longer available")
    record(db, "candidate_image_viewed", actor_id=user.id, case_id=job.case_id,
           detail=f"candidate_id={cand.id}")
    media = "image/png" if g.storage_key.endswith(".png") else "image/jpeg"
    return Response(storage.read(g.storage_key), media_type=media, headers={"Cache-Control": "no-store"})
