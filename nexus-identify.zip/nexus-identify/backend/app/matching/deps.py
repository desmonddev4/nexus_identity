from functools import lru_cache

from fastapi import HTTPException, status

from ..config import settings
from .embedder import FaceEmbedder, SFaceEmbedder


@lru_cache
def _load() -> FaceEmbedder:
    return SFaceEmbedder(settings.matching_model_dir)


def get_embedder() -> FaceEmbedder:
    try:
        return _load()
    except FileNotFoundError as e:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, f"Recognition model not installed: {e}")
