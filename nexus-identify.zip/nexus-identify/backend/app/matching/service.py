import cv2
import numpy as np
from fastapi import HTTPException, status
from sqlalchemy import delete
from sqlalchemy.orm import Session

from ..audit.service import record
from ..models import Embedding, User
from .embedder import EmbeddingError, FaceEmbedder


def decode_image(data: bytes) -> np.ndarray:
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise EmbeddingError("corrupt")
    return img


def embed_or_reject(db: Session, embedder: FaceEmbedder, data: bytes,
                    user: User, case_id: int | None) -> np.ndarray:
    try:
        return embedder.embed(decode_image(data))
    except EmbeddingError as e:
        record(db, "image_rejected", actor_id=user.id, case_id=case_id, detail=e.code)
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, {"reasons": [e.code], "metrics": {}})


def delete_embeddings(db: Session, gallery_id: int) -> None:
    db.execute(delete(Embedding).where(Embedding.gallery_record_id == gallery_id))
