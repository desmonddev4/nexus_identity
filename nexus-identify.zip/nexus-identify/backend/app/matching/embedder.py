"""Replaceable face-embedding module.

Default implementation: OpenCV Zoo YuNet (detector) + SFace (128-d recognizer), both Apache-2.0
code/packaging. Swap in another model by implementing FaceEmbedder; embeddings from different
models are NOT comparable, so every stored embedding carries its model_version.
"""
import threading
from pathlib import Path
from typing import Protocol

import cv2
import numpy as np

DETECTOR_FILE = "face_detection_yunet_2023mar.onnx"
RECOGNIZER_FILE = "face_recognition_sface_2021dec.onnx"


class EmbeddingError(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


class FaceEmbedder(Protocol):
    model_version: str

    def embed(self, img_bgr: np.ndarray) -> np.ndarray:
        """Return an L2-normalised float32 vector for the single face in the image."""
        ...


class SFaceEmbedder:
    def __init__(self, model_dir: str | Path):
        d = Path(model_dir)
        det, rec = d / DETECTOR_FILE, d / RECOGNIZER_FILE
        for f in (det, rec):
            if not f.is_file():
                raise FileNotFoundError(f"{f} not found (run: python scripts/download_models.py)")
        self._detector = cv2.FaceDetectorYN.create(str(det), "", (320, 320), 0.8, 0.3, 5000)
        self._recognizer = cv2.FaceRecognizerSF.create(str(rec), "")
        self._lock = threading.Lock()   # detector input size is shared state
        self.model_version = "opencv-yunet-2023mar+sface-2021dec"

    def embed(self, img_bgr: np.ndarray) -> np.ndarray:
        h, w = img_bgr.shape[:2]
        with self._lock:
            self._detector.setInputSize((w, h))
            _, faces = self._detector.detect(img_bgr)
            if faces is None or len(faces) == 0:
                raise EmbeddingError("no_face_detected")
            if len(faces) > 1:
                raise EmbeddingError("multiple_faces")
            aligned = self._recognizer.alignCrop(img_bgr, faces[0])
            feat = self._recognizer.feature(aligned)
        vec = np.asarray(feat, dtype=np.float32).flatten()
        norm = float(np.linalg.norm(vec))
        if norm == 0.0:
            raise EmbeddingError("embedding_failed")
        return vec / norm
