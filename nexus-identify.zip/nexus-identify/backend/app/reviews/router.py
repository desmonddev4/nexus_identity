from datetime import datetime
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..audit.service import record
from ..auth.deps import require_roles
from ..db import get_db
from ..images.router import READ_ROLES, _case_for, _require_active_authorization
from ..models import (Candidate, Case, CaseNote, CaseStatus, GalleryRecord, ReviewDecision,
                      Role, SearchJob, User)

router = APIRouter(tags=["reviews"])

REVIEW_ROLES = (Role.reviewer, Role.admin)
NOTE_ROLES = (Role.investigator, Role.reviewer, Role.admin)
MIN_REASON = 10
WARNING = ("A confirmed candidate is an investigative lead only. It is not an identification and is not "
           "grounds for arrest, accusation or adverse action without independent verification.")


def visible_case(db: Session, case_id: int, user: User) -> Case:
    """Case access for read-only/oversight purposes (auditors included)."""
    case = db.get(Case, case_id)
    ok = case is not None and (user.role in (Role.admin, Role.auditor, Role.reviewer) or case.owner_id == user.id)
    if not ok:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Case not found")
    return case


def _candidate(db: Session, candidate_id: int) -> tuple[Candidate, SearchJob]:
    cand = db.get(Candidate, candidate_id)
    job = db.get(SearchJob, cand.search_job_id) if cand else None
    if not cand or not job:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Candidate not found")
    return cand, job


class DecisionIn(BaseModel):
    decision: Literal["confirmed", "rejected", "inconclusive"]
    reason: str


class DecisionOut(BaseModel):
    id: int
    candidate_id: int
    reviewer_id: int
    reviewer_name: str
    decision: str
    reason: str
    created_at: datetime
    warning: str | None = None


class QueueItem(BaseModel):
    candidate_id: int
    rank: int
    score: float
    source: str
    case_id: int
    case_ref: str
    search_id: int
    reference_image_id: int
    created_at: datetime


class NoteIn(BaseModel):
    body: str


class NoteOut(BaseModel):
    id: int
    author_id: int
    author_name: str
    body: str
    created_at: datetime


def _decision_out(d: ReviewDecision, name: str, warn: bool = False) -> DecisionOut:
    return DecisionOut(id=d.id, candidate_id=d.candidate_id, reviewer_id=d.reviewer_id, reviewer_name=name,
                       decision=d.decision, reason=d.reason, created_at=d.created_at,
                       warning=WARNING if warn and d.decision == "confirmed" else None)


@router.get("/reviews/pending", response_model=list[QueueItem])
def pending_queue(db: Session = Depends(get_db), user: User = Depends(require_roles(*REVIEW_ROLES))):
    rows = db.execute(
        select(Candidate, SearchJob, Case)
        .join(SearchJob, SearchJob.id == Candidate.search_job_id)
        .join(Case, Case.id == SearchJob.case_id)
        .join(GalleryRecord, GalleryRecord.id == Candidate.gallery_record_id)
        .where(Candidate.review_status == "pending", SearchJob.requested_by != user.id,
               Case.status == CaseStatus.approved, GalleryRecord.status == "active")
        .order_by(Candidate.id)
    ).all()
    return [QueueItem(candidate_id=c.id, rank=c.rank, score=round(c.score, 4), source=c.gallery_record.source,
                      case_id=case.id, case_ref=case.case_ref, search_id=job.id,
                      reference_image_id=job.reference_image_id, created_at=job.created_at)
            for c, job, case in rows]


@router.post("/candidates/{candidate_id}/decisions", response_model=DecisionOut, status_code=201)
def decide(candidate_id: int, body: DecisionIn, db: Session = Depends(get_db),
           user: User = Depends(require_roles(*REVIEW_ROLES))):
    cand, job = _candidate(db, candidate_id)
    case = _case_for(db, job.case_id, user, write=False)
    _require_active_authorization(case)
    if job.requested_by == user.id:
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            "The person who ran a search cannot review its results (independent review required)")
    reason = body.reason.strip()
    if len(reason) < MIN_REASON:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                            f"A written reason of at least {MIN_REASON} characters is required")
    d = ReviewDecision(candidate_id=cand.id, reviewer_id=user.id, decision=body.decision, reason=reason)
    db.add(d)
    cand.review_status = body.decision
    db.commit()
    db.refresh(d)
    record(db, "review_decision", actor_id=user.id, case_id=case.id,
           detail=f"candidate_id={cand.id} decision={d.decision}")
    return _decision_out(d, user.name, warn=True)


@router.get("/candidates/{candidate_id}/decisions", response_model=list[DecisionOut])
def decision_history(candidate_id: int, db: Session = Depends(get_db),
                     user: User = Depends(require_roles(*READ_ROLES, Role.auditor))):
    _, job = _candidate(db, candidate_id)
    visible_case(db, job.case_id, user)
    rows = db.scalars(select(ReviewDecision).where(ReviewDecision.candidate_id == candidate_id)
                      .order_by(ReviewDecision.id)).all()
    names = {u.id: u.name for u in db.scalars(select(User).where(User.id.in_({r.reviewer_id for r in rows}))).all()}
    return [_decision_out(r, names.get(r.reviewer_id, "?")) for r in rows]


# ---------------- case notes ----------------

@router.post("/cases/{case_id}/notes", response_model=NoteOut, status_code=201)
def add_note(case_id: int, body: NoteIn, db: Session = Depends(get_db),
             user: User = Depends(require_roles(*NOTE_ROLES))):
    case = _case_for(db, case_id, user, write=False)
    text = body.body.strip()
    if not text:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Note cannot be empty")
    n = CaseNote(case_id=case.id, author_id=user.id, body=text)
    db.add(n)
    db.commit()
    db.refresh(n)
    record(db, "case_note_added", actor_id=user.id, case_id=case.id, detail=f"note_id={n.id}")
    return NoteOut(id=n.id, author_id=user.id, author_name=user.name, body=n.body, created_at=n.created_at)


@router.get("/cases/{case_id}/notes", response_model=list[NoteOut])
def list_notes(case_id: int, db: Session = Depends(get_db), user: User = Depends(require_roles(*NOTE_ROLES))):
    case = _case_for(db, case_id, user, write=False)
    rows = db.execute(select(CaseNote, User.name).join(User, User.id == CaseNote.author_id)
                      .where(CaseNote.case_id == case.id).order_by(CaseNote.id)).all()
    return [NoteOut(id=n.id, author_id=n.author_id, author_name=name, body=n.body, created_at=n.created_at)
            for n, name in rows]
