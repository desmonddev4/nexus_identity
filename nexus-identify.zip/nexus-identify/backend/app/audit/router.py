from datetime import datetime

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth.deps import require_roles
from ..db import get_db
from ..models import AuditEvent, Role, User

router = APIRouter(prefix="/audit", tags=["audit"])


class AuditOut(BaseModel):
    id: int
    actor_id: int | None
    action: str
    case_id: int | None
    detail: str | None
    timestamp: datetime
    model_config = {"from_attributes": True}


@router.get("", response_model=list[AuditOut])
def list_events(limit: int = 100, db: Session = Depends(get_db),
                _: User = Depends(require_roles(Role.auditor, Role.admin))):
    return db.scalars(select(AuditEvent).order_by(AuditEvent.id.desc()).limit(min(limit, 500))).all()
