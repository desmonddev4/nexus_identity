from sqlalchemy.orm import Session

from ..models import AuditEvent


def record(db: Session, action: str, actor_id: int | None = None,
           case_id: int | None = None, detail: str | None = None) -> None:
    db.add(AuditEvent(actor_id=actor_id, action=action, case_id=case_id, detail=detail))
    db.commit()
