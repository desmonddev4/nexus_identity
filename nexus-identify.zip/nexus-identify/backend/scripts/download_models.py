"""Download the OpenCV Zoo YuNet + SFace ONNX models (Apache-2.0) into ./models.

    python scripts/download_models.py [--dir models]

Records each file's SHA-256 so the exact model used is documented (put it in docs/model-selection.md).
"""
import argparse
import hashlib
import sys
import urllib.request
from pathlib import Path

FILES = {
    "face_detection_yunet_2023mar.onnx": "models/face_detection_yunet/face_detection_yunet_2023mar.onnx",
    "face_recognition_sface_2021dec.onnx": "models/face_recognition_sface/face_recognition_sface_2021dec.onnx",
}
BASES = [
    "https://huggingface.co/opencv/opencv_zoo/resolve/main/",
    "https://github.com/opencv/opencv_zoo/raw/main/",
]


def fetch(rel: str) -> bytes:
    last = None
    for base in BASES:
        try:
            with urllib.request.urlopen(base + rel, timeout=60) as r:
                data = r.read()
            if len(data) > 100_000 and not data.startswith(b"version https://git-lfs"):
                return data
            last = "response was too small / a git-lfs pointer"
        except Exception as e:  # noqa: BLE001
            last = e
    raise RuntimeError(f"Could not download {rel}: {last}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="models")
    out = Path(ap.parse_args().dir)
    out.mkdir(parents=True, exist_ok=True)
    for name, rel in FILES.items():
        data = fetch(rel)
        (out / name).write_bytes(data)
        print(f"{name}  {len(data):>10} bytes  sha256={hashlib.sha256(data).hexdigest()}")
    print("Done. Record these hashes in docs/model-selection.md")


if __name__ == "__main__":
    try:
        main()
    except RuntimeError as e:
        sys.exit(str(e))
