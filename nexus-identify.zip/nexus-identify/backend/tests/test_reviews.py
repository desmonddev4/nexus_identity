from tests.helpers import RED, color_png
from tests.test_matching import add_gallery, case_with_ref, search

GOOD = "Face shape and scars differ clearly from reference."


def setup_candidate(client, users, monkeypatch):
    cid, rid = case_with_ref(client, users, monkeypatch, RED)
    add_gallery(client, users, RED, "red volunteer")
    body = search(client, users, cid, rid).json()
    return cid, body["id"], body["candidates"][0]["id"]


def decide(client, users, cand, who="rev", decision="rejected", reason=GOOD):
    return client.post(f"/candidates/{cand}/decisions", headers=users[who],
                       json={"decision": decision, "reason": reason})


def test_reviewer_decision_updates_status_and_warns_on_confirm(client, users, monkeypatch):
    cid, sid, cand = setup_candidate(client, users, monkeypatch)
    r = decide(client, users, cand, decision="confirmed")
    assert r.status_code == 201 and "not an identification" in r.json()["warning"]
    got = client.get(f"/searches/{sid}", headers=users["rev"]).json()["candidates"][0]
    assert got["review_status"] == "confirmed"
    hist = client.get(f"/candidates/{cand}/decisions", headers=users["aud"]).json()
    assert len(hist) == 1 and hist[0]["reviewer_name"] == "rev"


def test_reason_and_value_validation(client, users, monkeypatch):
    _, _, cand = setup_candidate(client, users, monkeypatch)
    assert decide(client, users, cand, reason="short").status_code == 422
    assert decide(client, users, cand, reason="   ").status_code == 422
    assert decide(client, users, cand, decision="identified").status_code == 422


def test_search_runner_cannot_review_own_results(client, users, monkeypatch):
    _, _, cand = setup_candidate(client, users, monkeypatch)
    assert decide(client, users, cand, who="inv1").status_code == 403     # wrong role
    assert decide(client, users, cand, who="aud").status_code == 403


def test_admin_who_ran_search_cannot_review_it(client, users, monkeypatch):
    from app.images import router as images_router
    from tests.helpers import passthrough
    monkeypatch.setattr(images_router, "process_upload", passthrough)
    h = users["admin"]
    cid = client.post("/cases", headers=h, json={"case_ref": "ADM-1", "purpose": "test",
                                                 "retention_date": "2099-01-01T00:00:00Z"}).json()["id"]
    client.post(f"/cases/{cid}/approve", headers=h, json={"scope": "t", "expires_at": "2099-01-01T00:00:00Z"})
    rid = client.post(f"/cases/{cid}/reference-images", headers=h, data={"source": "s"},
                      files={"file": ("r.png", color_png(RED), "image/png")}).json()["id"]
    add_gallery(client, users, RED, "red volunteer")
    cand = client.post(f"/cases/{cid}/searches", headers=h, json={"reference_image_id": rid}).json()["candidates"][0]["id"]
    assert decide(client, users, cand["id"] if isinstance(cand, dict) else cand, who="admin").status_code == 403
    assert decide(client, users, cand["id"] if isinstance(cand, dict) else cand, who="rev").status_code == 201


def test_queue_lists_pending_then_empties(client, users, monkeypatch):
    _, _, cand = setup_candidate(client, users, monkeypatch)
    q = client.get("/reviews/pending", headers=users["rev"]).json()
    assert [i["candidate_id"] for i in q] == [cand] and q[0]["case_ref"] == "GH-9"
    assert client.get("/reviews/pending", headers=users["inv1"]).status_code == 403
    decide(client, users, cand, decision="inconclusive")
    assert client.get("/reviews/pending", headers=users["rev"]).json() == []


def test_latest_decision_wins_and_history_kept(client, users, monkeypatch):
    cid, sid, cand = setup_candidate(client, users, monkeypatch)
    decide(client, users, cand, decision="confirmed")
    decide(client, users, cand, decision="rejected", reason="On second look the ear shapes do not match.")
    assert client.get(f"/searches/{sid}", headers=users["rev"]).json()["candidates"][0]["review_status"] == "rejected"
    hist = client.get(f"/candidates/{cand}/decisions", headers=users["rev"]).json()
    assert [h["decision"] for h in hist] == ["confirmed", "rejected"]


def test_case_notes(client, users, monkeypatch):
    cid, _, _ = setup_candidate(client, users, monkeypatch)
    assert client.post(f"/cases/{cid}/notes", headers=users["inv1"], json={"body": "Spoke to the family."}).status_code == 201
    assert client.post(f"/cases/{cid}/notes", headers=users["rev"], json={"body": "Reviewed lead 1."}).status_code == 201
    assert client.post(f"/cases/{cid}/notes", headers=users["inv1"], json={"body": "  "}).status_code == 422
    assert client.post(f"/cases/{cid}/notes", headers=users["inv2"], json={"body": "x"}).status_code == 404
    assert client.post(f"/cases/{cid}/notes", headers=users["aud"], json={"body": "x"}).status_code == 403
    notes = client.get(f"/cases/{cid}/notes", headers=users["inv1"]).json()
    assert [n["author_name"] for n in notes] == ["inv1", "rev"]


def test_report_contents_and_access(client, users, monkeypatch):
    cid, _, cand = setup_candidate(client, users, monkeypatch)
    decide(client, users, cand, decision="confirmed")
    client.post(f"/cases/{cid}/notes", headers=users["inv1"], json={"body": "Spoke to the family."})
    r = client.get(f"/cases/{cid}/report", headers=users["aud"])
    assert r.status_code == 200
    rep = r.json()
    assert rep["case"]["case_ref"] == "GH-9" and rep["reference_images"] == 1
    c = rep["searches"][0]["candidates"][0]
    assert c["review_status"] == "confirmed" and c["decisions"][0]["reviewer"] == "rev"
    assert rep["notes"][0]["body"] == "Spoke to the family."
    assert {"search_run", "review_decision"} <= {e["action"] for e in rep["audit"]}
    assert "arrest" in rep["disclaimer"]
    assert "storage_key" not in r.text and "blob" not in r.text
    assert client.get(f"/cases/{cid}/report", headers=users["inv2"]).status_code == 404


def test_stats(client, users, monkeypatch):
    _, _, cand = setup_candidate(client, users, monkeypatch)
    s = client.get("/stats", headers=users["rev"]).json()
    assert s["searches"] == 1 and s["pending_review"] == 1
    decide(client, users, cand, decision="confirmed")
    s = client.get("/stats", headers=users["inv1"]).json()
    assert s["pending_review"] == 0 and s["decisions"] == {"confirmed": 1}
    assert client.get("/stats", headers=users["inv2"]).json()["cases"] == {}
