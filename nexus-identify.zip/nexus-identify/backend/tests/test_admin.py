from tests.helpers import RED, color_png
from tests.test_matching import add_gallery, case_with_ref

PW = "pass12345"


def user_id(client, users, email):
    return next(u["id"] for u in client.get("/auth/users", headers=users["admin"]).json() if u["email"] == email)


def test_user_listing_is_admin_only(client, users):
    assert client.get("/auth/users", headers=users["inv1"]).status_code == 403
    assert len(client.get("/auth/users", headers=users["admin"]).json()) == 5


def test_suspend_blocks_token_and_login_then_reactivate(client, users):
    uid = user_id(client, users, "inv2@t.io")
    assert client.patch(f"/auth/users/{uid}", json={"status": "suspended"}, headers=users["admin"]).status_code == 200
    assert client.get("/auth/me", headers=users["inv2"]).status_code == 401
    assert client.post("/auth/login", data={"username": "inv2@t.io", "password": PW}).status_code == 401
    client.patch(f"/auth/users/{uid}", json={"status": "active"}, headers=users["admin"])
    assert client.post("/auth/login", data={"username": "inv2@t.io", "password": PW}).status_code == 200


def test_admin_cannot_change_own_role_or_suspend(client, users):
    me = client.get("/auth/me", headers=users["admin"]).json()["id"]
    assert client.patch(f"/auth/users/{me}", json={"status": "suspended"}, headers=users["admin"]).status_code == 403
    assert client.patch(f"/auth/users/{me}", json={"role": "auditor"}, headers=users["admin"]).status_code == 403


def test_role_change_and_password_reset(client, users):
    uid = user_id(client, users, "inv2@t.io")
    assert client.patch(f"/auth/users/{uid}", json={"role": "reviewer"}, headers=users["admin"]).json()["role"] == "reviewer"
    assert client.get("/reviews/pending", headers=users["inv2"]).status_code == 200
    assert client.patch(f"/auth/users/{uid}", json={"password": "short"}, headers=users["admin"]).status_code == 422
    client.patch(f"/auth/users/{uid}", json={"password": "a-brand-new-pass"}, headers=users["admin"])
    assert client.post("/auth/login", data={"username": "inv2@t.io", "password": PW}).status_code == 401
    assert client.post("/auth/login", data={"username": "inv2@t.io", "password": "a-brand-new-pass"}).status_code == 200
    actions = [e["action"] for e in client.get("/audit", headers=users["admin"]).json()]
    assert "user_updated" in actions


def test_close_reopen_and_closed_case_is_locked(client, users, monkeypatch):
    cid, rid = case_with_ref(client, users, monkeypatch, RED)
    assert client.post(f"/cases/{cid}/close", headers=users["inv2"]).status_code == 404
    assert client.post(f"/cases/{cid}/close", headers=users["inv1"]).json()["status"] == "closed"
    assert client.post(f"/cases/{cid}/close", headers=users["inv1"]).status_code == 409
    up = client.post(f"/cases/{cid}/reference-images", headers=users["inv1"], data={"source": "s"},
                     files={"file": ("r.png", color_png(RED), "image/png")})
    assert up.status_code == 403
    assert client.post(f"/cases/{cid}/searches", headers=users["inv1"], json={"reference_image_id": rid}).status_code == 403
    assert client.post(f"/cases/{cid}/reopen", headers=users["inv1"]).status_code == 403
    assert client.post(f"/cases/{cid}/reopen", headers=users["admin"]).json()["status"] == "approved"
    assert client.post(f"/cases/{cid}/reopen", headers=users["admin"]).status_code == 409


def test_retention_update_rules(client, users, monkeypatch):
    cid, _ = case_with_ref(client, users, monkeypatch, RED)
    body = {"retention_date": "2098-06-01T00:00:00Z"}
    assert client.post(f"/cases/{cid}/retention", json=body, headers=users["inv1"]).status_code == 403
    assert client.post(f"/cases/{cid}/retention", json={"retention_date": "2001-01-01T00:00:00Z"},
                       headers=users["admin"]).status_code == 422
    assert client.post(f"/cases/{cid}/retention", json=body, headers=users["admin"]).status_code == 200
    events = client.get("/audit", headers=users["aud"]).json()
    assert any(e["action"] == "case_retention_updated" and "2098-06-01" in e["detail"] for e in events)


def test_admin_can_view_gallery_image_and_it_is_audited(client, users, monkeypatch):
    case_with_ref(client, users, monkeypatch, RED)       # also patches process_upload
    gid = add_gallery(client, users, RED, "red volunteer")
    r = client.get(f"/gallery/{gid}/image", headers=users["admin"])
    assert r.status_code == 200 and r.content == color_png(RED)
    assert client.get(f"/gallery/{gid}/image", headers=users["inv1"]).status_code == 403
    assert "gallery_image_viewed" in [e["action"] for e in client.get("/audit", headers=users["aud"]).json()]
