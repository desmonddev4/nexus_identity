import hashlib

import cv2
import numpy as np

from app.images.validation import ProcessedImage, QualityReport
from app.matching.embedder import EmbeddingError

RED, NEAR_RED, GREEN, BLUE, BLACK = (0, 0, 255), (10, 0, 250), (0, 255, 0), (255, 0, 0), (0, 0, 0)


def color_png(bgr=(128, 128, 128), size=300) -> bytes:
    img = np.zeros((size, size, 3), np.uint8)
    img[:] = bgr
    return cv2.imencode(".png", img)[1].tobytes()


def passthrough(data: bytes) -> ProcessedImage:
    """Stands in for process_upload so tests can use flat-colour images."""
    report = QualityReport(True, [], {"faces_detected": 1, "face_px": 120, "blur_score": 100.0, "brightness": 128.0})
    return ProcessedImage(data, ".png", "image/png", hashlib.sha256(data).hexdigest(), report)


class FakeEmbedder:
    """Embeds an image as its mean B,G,R colour: controllable similarity for tests."""
    model_version = "fake-v1"

    def embed(self, img: np.ndarray) -> np.ndarray:
        v = img.reshape(-1, 3).mean(axis=0).astype(np.float32)
        n = float(np.linalg.norm(v))
        if n == 0:
            raise EmbeddingError("no_face_detected")
        return v / n
