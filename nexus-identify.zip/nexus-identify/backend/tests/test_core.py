CASE = {"case_ref": "GH-001", "purpose": "Missing person lead review",
        "retention_date": "2030-01-01T00:00:00Z"}


def test_login_fails_with_wrong_password(client, users):
    r = client.post("/auth/login", data={"username": "admin@t.io", "password": "nope"})
    assert r.status_code == 401


def test_protected_route_needs_token(client):
    assert client.get("/cases").status_code == 401


def test_only_admin_creates_users(client, users):
    body = {"name": "X", "email": "x@t.io", "password": "pass12345", "role": "reviewer"}
    assert client.post("/auth/users", json=body, headers=users["inv1"]).status_code == 403
    assert client.post("/auth/users", json=body, headers=users["admin"]).status_code == 201


def test_investigator_only_sees_own_cases(client, users):
    r = client.post("/cases", json=CASE, headers=users["inv1"])
    assert r.status_code == 201
    cid = r.json()["id"]
    assert client.get(f"/cases/{cid}", headers=users["inv2"]).status_code == 404
    assert client.get("/cases", headers=users["inv2"]).json() == []
    assert client.get(f"/cases/{cid}", headers=users["inv1"]).status_code == 200


def test_case_requires_purpose(client, users):
    bad = {**CASE, "purpose": "  "}
    assert client.post("/cases", json=bad, headers=users["inv1"]).status_code == 422


def test_only_admin_approves(client, users):
    cid = client.post("/cases", json=CASE, headers=users["inv1"]).json()["id"]
    body = {"scope": "test gallery only", "expires_at": "2030-01-01T00:00:00Z"}
    assert client.post(f"/cases/{cid}/approve", json=body, headers=users["inv1"]).status_code == 403
    r = client.post(f"/cases/{cid}/approve", json=body, headers=users["admin"])
    assert r.status_code == 200 and r.json()["status"] == "approved"


def test_audit_visible_to_auditor_not_investigator(client, users):
    client.post("/cases", json=CASE, headers=users["inv1"])
    assert client.get("/audit", headers=users["inv1"]).status_code == 403
    events = client.get("/audit", headers=users["aud"]).json()
    assert any(e["action"] == "case_created" for e in events)
