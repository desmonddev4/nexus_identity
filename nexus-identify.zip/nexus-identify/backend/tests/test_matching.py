from app.images import router as images_router
from app.models import Embedding
from tests.helpers import BLACK, BLUE, GREEN, NEAR_RED, RED, color_png, passthrough


def case_with_ref(client, users, monkeypatch, ref_color, approve=True, who="inv1"):
    monkeypatch.setattr(images_router, "process_upload", passthrough)
    cid = client.post("/cases", json={"case_ref": "GH-9", "purpose": "test",
                                      "retention_date": "2099-01-01T00:00:00Z"}, headers=users["inv1"]).json()["id"]
    if approve:
        client.post(f"/cases/{cid}/approve", headers=users["admin"],
                    json={"scope": "test gallery", "expires_at": "2099-01-01T00:00:00Z"})
        r = client.post(f"/cases/{cid}/reference-images", data={"source": "synthetic"},
                        files={"file": ("r.png", color_png(ref_color), "image/png")}, headers=users[who])
        assert r.status_code == 201, r.text
        return cid, r.json()["id"]
    return cid, 1


def add_gallery(client, users, color, source):
    r = client.post("/gallery", headers=users["admin"],
                    data={"source": source, "permission_basis": "consent form", "delete_after": "2099-01-01T00:00:00Z"},
                    files={"file": ("g.png", color_png(color), "image/png")})
    assert r.status_code == 201, r.text
    return r.json()["id"]


def search(client, users, cid, rid, who="inv1"):
    return client.post(f"/cases/{cid}/searches", json={"reference_image_id": rid}, headers=users[who])


def test_ranked_candidates_and_threshold(client, users, monkeypatch):
    cid, rid = case_with_ref(client, users, monkeypatch, RED)
    add_gallery(client, users, NEAR_RED, "near-red volunteer")
    add_gallery(client, users, RED, "red volunteer")
    add_gallery(client, users, GREEN, "green volunteer")
    r = search(client, users, cid, rid)
    assert r.status_code == 201
    body = r.json()
    assert body["outcome"] == "candidates" and body["gallery_size"] == 3
    assert [c["source"] for c in body["candidates"]] == ["red volunteer", "near-red volunteer"]
    assert [c["rank"] for c in body["candidates"]] == [1, 2]
    assert body["candidates"][0]["score"] >= body["candidates"][1]["score"]
    assert all(c["review_status"] == "pending" for c in body["candidates"])
    assert "human review" in body["notice"] and body["model_version"] == "fake-v1"


def test_no_match_is_a_valid_outcome(client, users, monkeypatch):
    cid, rid = case_with_ref(client, users, monkeypatch, BLUE)
    add_gallery(client, users, GREEN, "green volunteer")
    body = search(client, users, cid, rid).json()
    assert body["outcome"] == "no_match" and body["candidates"] == []


def test_empty_gallery_is_no_match(client, users, monkeypatch):
    cid, rid = case_with_ref(client, users, monkeypatch, RED)
    body = search(client, users, cid, rid).json()
    assert body["outcome"] == "no_match" and body["gallery_size"] == 0


def test_search_requires_approved_case(client, users, monkeypatch):
    cid, rid = case_with_ref(client, users, monkeypatch, RED, approve=False)
    assert search(client, users, cid, rid).status_code == 403


def test_access_rules(client, users, monkeypatch):
    cid, rid = case_with_ref(client, users, monkeypatch, RED)
    add_gallery(client, users, RED, "red volunteer")
    assert search(client, users, cid, rid, who="inv2").status_code == 404
    assert search(client, users, cid, rid, who="rev").status_code == 403
    sid = search(client, users, cid, rid).json()["id"]
    assert client.get(f"/searches/{sid}", headers=users["rev"]).status_code == 200
    assert client.get(f"/searches/{sid}", headers=users["aud"]).status_code == 403
    assert client.get(f"/searches/{sid}", headers=users["inv2"]).status_code == 404


def test_candidate_image_view_is_audited(client, users, monkeypatch):
    cid, rid = case_with_ref(client, users, monkeypatch, RED)
    add_gallery(client, users, RED, "red volunteer")
    cand = search(client, users, cid, rid).json()["candidates"][0]
    img = client.get(f"/candidates/{cand['id']}/image", headers=users["rev"])
    assert img.status_code == 200 and img.content == color_png(RED)
    actions = [e["action"] for e in client.get("/audit", headers=users["aud"]).json()]
    assert "search_run" in actions and "candidate_image_viewed" in actions


def test_embeddings_encrypted_and_removed_with_gallery_record(client, users, db_session, storage, monkeypatch):
    cid, rid = case_with_ref(client, users, monkeypatch, RED)
    gid = add_gallery(client, users, RED, "red volunteer")
    emb = db_session.query(Embedding).one()
    raw = storage.unseal(emb.blob)
    assert len(raw) == 3 * 4 and emb.blob != raw           # sealed, not plain float bytes
    assert client.delete(f"/gallery/{gid}", headers=users["admin"]).status_code == 200
    db_session.expire_all()
    assert db_session.query(Embedding).count() == 0
    assert search(client, users, cid, rid).json()["outcome"] == "no_match"


def test_gallery_image_without_usable_face_is_rejected(client, users, monkeypatch):
    monkeypatch.setattr(images_router, "process_upload", passthrough)
    r = client.post("/gallery", headers=users["admin"],
                    data={"source": "x", "permission_basis": "y", "delete_after": "2099-01-01T00:00:00Z"},
                    files={"file": ("g.png", color_png(BLACK), "image/png")})
    assert r.status_code == 422 and "no_face_detected" in r.json()["detail"]["reasons"]
    assert client.get("/gallery", headers=users["admin"]).json() == []
