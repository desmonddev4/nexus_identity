import cv2
import numpy as np
import pytest

from app.config import settings
from app.images import router as images_router
from app.images.validation import ProcessedImage, QualityReport
from app.models import ReferenceImage
from app.retention import purge_expired
from tests.helpers import passthrough

FAKE = b"\x89PNG\r\n\x1a\nfake-image-bytes"


def good(_data):
    return ProcessedImage(FAKE, ".png", "image/png", "ab" * 32, QualityReport(True, [], {"faces_detected": 1}))


def png_bytes():
    ok, buf = cv2.imencode(".png", np.full((300, 300, 3), 128, np.uint8))
    return buf.tobytes()


def upload(client, headers, cid, data=None, source="synthetic test image"):
    return client.post(f"/cases/{cid}/reference-images", data={"source": source},
                       files={"file": ("a.png", data or png_bytes(), "image/png")}, headers=headers)


def make_case(client, users, approve=True, retention="2099-01-01T00:00:00Z", ref="GH-001"):
    cid = client.post("/cases", json={"case_ref": ref, "purpose": "test", "retention_date": retention},
                      headers=users["inv1"]).json()["id"]
    if approve:
        client.post(f"/cases/{cid}/approve", headers=users["admin"],
                    json={"scope": "test gallery", "expires_at": "2099-01-01T00:00:00Z"})
    return cid


def test_upload_blocked_without_approval(client, users):
    cid = make_case(client, users, approve=False)
    assert upload(client, users["inv1"], cid).status_code == 403


def test_non_image_rejected(client, users):
    cid = make_case(client, users)
    assert upload(client, users["inv1"], cid, data=b"hello, not an image").status_code == 400


def test_faceless_image_rejected_with_reason(client, users):
    cid = make_case(client, users)
    r = upload(client, users["inv1"], cid)           # real analysis on a blank grey image
    assert r.status_code == 422
    assert "no_face_detected" in r.json()["detail"]["reasons"]


def test_oversize_rejected(client, users, monkeypatch):
    cid = make_case(client, users)
    monkeypatch.setattr(settings, "max_image_bytes", 10)
    assert upload(client, users["inv1"], cid).status_code == 413


def test_upload_view_delete_flow(client, users, db_session, storage, monkeypatch):
    monkeypatch.setattr(images_router, "process_upload", good)
    cid = make_case(client, users)

    r = upload(client, users["inv1"], cid)
    assert r.status_code == 201
    iid = r.json()["id"]
    assert "storage_key" not in r.json()

    key = db_session.get(ReferenceImage, iid).storage_key
    assert (storage.root / key).read_bytes() != FAKE        # encrypted on disk

    f = client.get(f"/reference-images/{iid}/file", headers=users["inv1"])
    assert f.status_code == 200 and f.content == FAKE
    assert client.get(f"/reference-images/{iid}/file", headers=users["rev"]).status_code == 200
    assert client.get(f"/reference-images/{iid}/file", headers=users["aud"]).status_code == 403
    assert client.get(f"/reference-images/{iid}/file", headers=users["inv2"]).status_code == 404

    events = [e["action"] for e in client.get("/audit", headers=users["aud"]).json()]
    assert "reference_image_uploaded" in events and "reference_image_viewed" in events

    assert client.delete(f"/reference-images/{iid}", headers=users["inv1"]).status_code == 200
    assert not (storage.root / key).exists()
    assert client.get(f"/cases/{cid}/reference-images", headers=users["inv1"]).json() == []


def test_gallery_rules(client, users, monkeypatch):
    monkeypatch.setattr(images_router, "process_upload", passthrough)
    files = {"file": ("g.png", png_bytes(), "image/png")}
    form = {"source": "consented volunteer", "permission_basis": "signed consent form #1",
            "delete_after": "2099-01-01T00:00:00Z"}
    assert client.post("/gallery", data=form, files=files, headers=users["inv1"]).status_code == 403
    assert client.post("/gallery", data={**form, "permission_basis": " "}, files=files,
                       headers=users["admin"]).status_code == 422
    assert client.post("/gallery", data={**form, "delete_after": "2000-01-01T00:00:00Z"}, files=files,
                       headers=users["admin"]).status_code == 422
    r = client.post("/gallery", data=form, files=files, headers=users["admin"])
    assert r.status_code == 201
    assert len(client.get("/gallery", headers=users["admin"]).json()) == 1
    assert client.delete(f"/gallery/{r.json()['id']}", headers=users["admin"]).status_code == 200
    assert client.get("/gallery", headers=users["admin"]).json() == []


def test_retention_purge_deletes_expired(client, users, db_session, storage, monkeypatch):
    monkeypatch.setattr(images_router, "process_upload", good)
    cid = make_case(client, users, retention="2020-01-01T00:00:00Z")
    iid = upload(client, users["inv1"], cid).json()["id"]
    key = db_session.get(ReferenceImage, iid).storage_key
    assert (storage.root / key).exists()

    assert purge_expired(db_session, storage) == {"reference": 1, "gallery": 0}
    assert not (storage.root / key).exists()
    db_session.expire_all()
    assert db_session.get(ReferenceImage, iid).status == "deleted"
