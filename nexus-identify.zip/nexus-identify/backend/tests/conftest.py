import pytest
from cryptography.fernet import Fernet
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.auth.security import hash_password
from app.db import Base, get_db
from app.images.storage import EncryptedLocalStorage, get_storage
from app.main import app
from app.matching.deps import get_embedder
from tests.helpers import FakeEmbedder
from app.models import Role, User


@pytest.fixture()
def db_session():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False},
                           poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False)
    with Session() as s:
        yield s


@pytest.fixture()
def storage(tmp_path):
    return EncryptedLocalStorage(tmp_path / "store", Fernet.generate_key().decode())


@pytest.fixture()
def client(db_session, storage):
    app.dependency_overrides[get_db] = lambda: db_session
    app.dependency_overrides[get_storage] = lambda: storage
    app.dependency_overrides[get_embedder] = lambda: FakeEmbedder()
    yield TestClient(app)
    app.dependency_overrides.clear()


def make_user(db, email, role):
    u = User(name=email.split("@")[0], email=email, role=role,
             password_hash=hash_password("pass12345"))
    db.add(u)
    db.commit()
    return u


def login(client, email):
    r = client.post("/auth/login", data={"username": email, "password": "pass12345"})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture()
def users(db_session, client):
    for email, role in [("admin@t.io", Role.admin), ("inv1@t.io", Role.investigator),
                        ("inv2@t.io", Role.investigator), ("aud@t.io", Role.auditor),
                        ("rev@t.io", Role.reviewer)]:
        make_user(db_session, email, role)
    return {k: login(client, f"{k}@t.io") for k in ["admin", "inv1", "inv2", "aud", "rev"]}
