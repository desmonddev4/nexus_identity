import numpy as np

from app.matching.similarity import rank_candidates


def unit(*v):
    a = np.array(v, dtype=np.float32)
    return a / np.linalg.norm(a)


def test_ranks_best_first_and_applies_threshold():
    m = np.vstack([unit(1, 0), unit(1, 1), unit(0, 1)])
    hits = rank_candidates(unit(1, 0), m, [10, 20, 30], threshold=0.5, limit=10)
    assert [h[0] for h in hits] == [10, 20]            # id 30 (cosine 0) is excluded
    assert hits[0][1] > hits[1][1]


def test_no_match_when_nothing_clears_threshold():
    m = np.vstack([unit(0, 1)])
    assert rank_candidates(unit(1, 0), m, [1], threshold=0.363, limit=10) == []


def test_empty_gallery_and_limit():
    assert rank_candidates(unit(1, 0), np.empty((0, 2), np.float32), [], 0.1, 5) == []
    m = np.vstack([unit(1, 0.01 * i) for i in range(5)])
    assert len(rank_candidates(unit(1, 0), m, list(range(5)), 0.1, limit=2)) == 2
