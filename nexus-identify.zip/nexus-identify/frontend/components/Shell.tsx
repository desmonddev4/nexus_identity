"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { api, clearToken, getToken, User } from "@/lib/api";

const UserCtx = createContext<User | null>(null);
export const useUser = () => useContext(UserCtx)!;

export default function Shell({ children }: { children: ReactNode }) {
  const router = useRouter();
  const path = usePathname();
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    if (!getToken()) { router.replace("/login"); return; }
    api.me().then(setUser).catch(() => { clearToken(); router.replace("/login"); });
  }, [router]);

  if (!user) return <div className="center muted">Loading…</div>;

  const links = [
    { href: "/dashboard", label: "Dashboard" },
    { href: "/cases", label: "Cases" },
    ...(user.role === "reviewer" || user.role === "admin" ? [{ href: "/reviews", label: "Review queue" }] : []),
    ...(user.role === "admin" ? [{ href: "/users", label: "Users" }, { href: "/gallery", label: "Gallery" }] : []),
    ...(user.role === "auditor" || user.role === "admin" ? [{ href: "/audit", label: "Audit log" }] : []),
  ];

  return (
    <UserCtx.Provider value={user}>
      <div className="layout">
        <aside className="sidebar">
          <div className="brand">Nexus Identify</div>
          <nav>
            {links.map((l) => (
              <Link key={l.href} href={l.href} className={path === l.href ? "active" : ""}>{l.label}</Link>
            ))}
          </nav>
          <div className="spacer" />
          <div className="who">
            <div>{user.name}</div>
            <div className="muted small">{user.role}</div>
            <button className="link" onClick={() => { clearToken(); router.replace("/login"); }}>
              Sign out
            </button>
          </div>
        </aside>
        <main className="content">
          <div className="banner">Prototype · results are possible matches only and require human review</div>
          {children}
        </main>
      </div>
    </UserCtx.Provider>
  );
}
