"use client";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";

function BlobImg({ load, alt }: { load: () => Promise<string>; alt: string }) {
  const [url, setUrl] = useState("");
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let u = "";
    load().then((x) => { u = x; setUrl(x); }).catch(() => setFailed(true));
    return () => { if (u) URL.revokeObjectURL(u); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  if (failed) return <div className="muted small">Image unavailable</div>;
  // eslint-disable-next-line @next/next/no-img-element
  return url ? <img src={url} alt={alt} style={{ width: "100%", borderRadius: 6 }} />
             : <div className="muted small">Loading…</div>;
}

export const RefImage = ({ id }: { id: number }) =>
  <BlobImg load={() => api.referenceBlobUrl(id)} alt="Reference" />;
export const CandImage = ({ id }: { id: number }) =>
  <BlobImg load={() => api.candidateBlobUrl(id)} alt="Candidate" />;
export const GalleryImage = ({ id }: { id: number }) =>
  <BlobImg load={() => api.galleryBlobUrl(id)} alt="Gallery" />;
