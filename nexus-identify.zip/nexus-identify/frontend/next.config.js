/** Proxy /api/* to the FastAPI backend so the browser makes same-origin requests (no CORS). */
const BACKEND = process.env.BACKEND_URL || "http://localhost:8000";

module.exports = {
  reactStrictMode: true,
  async rewrites() {
    return [{ source: "/api/:path*", destination: `${BACKEND}/:path*` }];
  },
};
