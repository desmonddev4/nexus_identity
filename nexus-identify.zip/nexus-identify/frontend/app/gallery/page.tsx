"use client";
import { FormEvent, useCallback, useEffect, useState } from "react";
import Shell, { useUser } from "@/components/Shell";
import { GalleryImage } from "@/components/Thumbs";
import { api, GalleryItem } from "@/lib/api";

function Inner() {
  const user = useUser();
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [source, setSource] = useState("");
  const [basis, setBasis] = useState("");
  const [deleteAfter, setDeleteAfter] = useState("");

  const load = useCallback(() => { api.gallery().then(setItems).catch((e) => setError(e.message)); }, []);
  useEffect(() => { if (user.role === "admin") load(); }, [user.role, load]);

  async function add(e: FormEvent) {
    e.preventDefault();
    if (!file) return;
    setBusy(true); setError("");
    try {
      await api.addGallery({ file, source, basis, deleteAfter: new Date(deleteAfter).toISOString() });
      setFile(null); setSource(""); setBasis(""); setDeleteAfter(""); (e.target as HTMLFormElement).reset(); load();
    } catch (err) { setError(err instanceof Error ? err.message : "Upload failed"); }
    finally { setBusy(false); }
  }

  async function remove(id: number) {
    if (!window.confirm("Permanently delete this gallery image and its facial representation?")) return;
    try { await api.deleteGallery(id); load(); } catch (err) { setError(err instanceof Error ? err.message : "Delete failed"); }
  }

  if (user.role !== "admin") return <div className="error">You do not have permission to manage the gallery.</div>;
  return (
    <>
      <h1>Authorized gallery</h1>
      <div className="muted small" style={{ marginBottom: 12 }}>
        Only add images you have documented permission to process. Every image needs a source, the basis of
        permission, and a deletion date.
      </div>
      {error && <div className="error">{error}</div>}
      <form className="panel" onSubmit={add} style={{ marginBottom: 20 }}>
        <div className="row">
          <div><label htmlFor="gs">Source</label>
            <input id="gs" value={source} onChange={(e) => setSource(e.target.value)} required placeholder="e.g. consenting volunteer" /></div>
          <div><label htmlFor="gd">Delete after</label>
            <input id="gd" type="date" value={deleteAfter} onChange={(e) => setDeleteAfter(e.target.value)} required /></div>
        </div>
        <label htmlFor="gb">Permission basis</label>
        <input id="gb" value={basis} onChange={(e) => setBasis(e.target.value)} required placeholder="e.g. signed consent form #12" />
        <label htmlFor="gf">Image (JPEG or PNG, one clear frontal face)</label>
        <input id="gf" type="file" accept="image/jpeg,image/png" required onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
        <button disabled={busy || !file}>{busy ? "Checking…" : "Add to gallery"}</button>
      </form>

      <div className="muted small" style={{ marginBottom: 8 }}>{items.length} image(s)</div>
      <div className="thumbs">
        {items.map((g) => (
          <div className="panel" key={g.id}>
            <GalleryImage id={g.id} />
            <div className="small" style={{ marginTop: 8 }}>{g.source}</div>
            <div className="muted small">{g.permission_basis}</div>
            <div className="muted small">Delete by {new Date(g.delete_after).toLocaleDateString()}</div>
            <button className="small" style={{ marginTop: 8 }} onClick={() => remove(g.id)}>Delete</button>
          </div>
        ))}
        {items.length === 0 && <div className="muted">The gallery is empty.</div>}
      </div>
    </>
  );
}

export default function Page() { return <Shell><Inner /></Shell>; }
