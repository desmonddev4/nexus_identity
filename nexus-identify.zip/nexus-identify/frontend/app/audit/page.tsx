"use client";
import { useEffect, useState } from "react";
import Shell, { useUser } from "@/components/Shell";
import { api, AuditEvent } from "@/lib/api";

function Inner() {
  const user = useUser();
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [error, setError] = useState("");
  const allowed = user.role === "auditor" || user.role === "admin";

  useEffect(() => { if (allowed) api.audit().then(setEvents).catch((e) => setError(e.message)); }, [allowed]);

  if (!allowed) return <div className="error">You do not have permission to view the audit log.</div>;
  return (
    <>
      <h1>Audit log</h1>
      {error && <div className="error">{error}</div>}
      <div className="panel">
        <table>
          <thead><tr><th>Time</th><th>Action</th><th>Actor</th><th>Case</th><th>Detail</th></tr></thead>
          <tbody>
            {events.map((e) => (
              <tr key={e.id}>
                <td>{new Date(e.timestamp).toLocaleString()}</td>
                <td>{e.action}</td>
                <td>{e.actor_id ?? "—"}</td>
                <td>{e.case_id ?? "—"}</td>
                <td className="muted">{e.detail ?? ""}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

export default function Page() { return <Shell><Inner /></Shell>; }
