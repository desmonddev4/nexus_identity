"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import Shell, { useUser } from "@/components/Shell";
import { CandImage, RefImage } from "@/components/Thumbs";
import { api, DecisionValue, QueueItem } from "@/lib/api";

function ReviewCard({ item, onDone }: { item: QueueItem; onDone: () => void }) {
  const [decision, setDecision] = useState<DecisionValue | null>(null);
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const [warning, setWarning] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    if (!decision) return;
    setBusy(true); setError("");
    try {
      const d = await api.decide(item.candidate_id, decision, reason);
      if (d.warning) { setWarning(d.warning); setTimeout(onDone, 2500); } else onDone();
    } catch (e) { setError(e instanceof Error ? e.message : "Failed"); setBusy(false); }
  }

  const opts: DecisionValue[] = ["confirmed", "rejected", "inconclusive"];
  return (
    <div className="panel" style={{ marginBottom: 16 }}>
      <div>
        <Link href={`/cases/${item.case_id}`}>{item.case_ref}</Link> · search #{item.search_id} · rank {item.rank} ·
        similarity {item.score.toFixed(3)}
      </div>
      <div className="muted small">Gallery source: {item.source}</div>
      <div className="pair" style={{ marginTop: 12 }}>
        <div><div className="muted small">Reference</div><RefImage id={item.reference_image_id} /></div>
        <div><div className="muted small">Candidate</div><CandImage id={item.candidate_id} /></div>
      </div>
      <div className="seg">
        {opts.map((o) => (
          <button key={o} className={decision === o ? "on" : ""} onClick={() => setDecision(o)}>{o}</button>
        ))}
      </div>
      <label htmlFor={`r${item.candidate_id}`}>Reason (required, at least 10 characters)</label>
      <textarea id={`r${item.candidate_id}`} rows={2} value={reason} onChange={(e) => setReason(e.target.value)} />
      {error && <div className="error">{error}</div>}
      {warning && <div className="panel" style={{ marginTop: 10 }}>{warning}</div>}
      <button disabled={!decision || busy || reason.trim().length < 10} onClick={submit}>Record decision</button>
    </div>
  );
}

function Inner() {
  const user = useUser();
  const [items, setItems] = useState<QueueItem[] | null>(null);
  const allowed = user.role === "reviewer" || user.role === "admin";
  const load = useCallback(() => { api.reviewQueue().then(setItems).catch(() => setItems([])); }, []);
  useEffect(() => { if (allowed) load(); }, [allowed, load]);

  if (!allowed) return <div className="error">You do not have permission to review candidates.</div>;
  return (
    <>
      <h1>Review queue</h1>
      <div className="muted small" style={{ marginBottom: 16 }}>
        Compare each pair yourself. A score is not an identification. Searches you ran are excluded
        (independent review).
      </div>
      {items === null && <div className="muted">Loading…</div>}
      {items?.length === 0 && <div className="panel muted">Nothing awaiting review.</div>}
      {items?.map((it) => <ReviewCard key={it.candidate_id} item={it} onDone={load} />)}
    </>
  );
}

export default function Page() { return <Shell><Inner /></Shell>; }
