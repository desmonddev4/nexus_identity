import "./globals.css";
import type { ReactNode } from "react";

export const metadata = { title: "Nexus Identify", description: "Nexus Sync Technologies — prototype" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
