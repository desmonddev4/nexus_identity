"use client";
import { FormEvent, useCallback, useEffect, useState } from "react";
import Shell, { useUser } from "@/components/Shell";
import Modal from "@/components/Modal";
import { api, Role, User } from "@/lib/api";

const ROLES: Role[] = ["admin", "investigator", "reviewer", "auditor"];

function Inner() {
  const me = useUser();
  const [users, setUsers] = useState<User[]>([]);
  const [error, setError] = useState("");
  const [creating, setCreating] = useState(false);
  const [resetFor, setResetFor] = useState<User | null>(null);
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "investigator" as Role });
  const [newPw, setNewPw] = useState("");

  const load = useCallback(() => { api.users().then(setUsers).catch((e) => setError(e.message)); }, []);
  useEffect(() => { if (me.role === "admin") load(); }, [me.role, load]);

  async function act(fn: () => Promise<unknown>) {
    setError("");
    try { await fn(); load(); } catch (e) { setError(e instanceof Error ? e.message : "Failed"); }
  }

  async function create(e: FormEvent) {
    e.preventDefault();
    await act(async () => { await api.createUser(form); setCreating(false); setForm({ name: "", email: "", password: "", role: "investigator" }); });
  }

  async function reset(e: FormEvent) {
    e.preventDefault();
    if (!resetFor) return;
    await act(async () => { await api.updateUser(resetFor.id, { password: newPw }); setResetFor(null); setNewPw(""); });
  }

  if (me.role !== "admin") return <div className="error">You do not have permission to manage users.</div>;
  return (
    <>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1>Users</h1>
        <button onClick={() => setCreating(true)} style={{ margin: 0 }}>New user</button>
      </div>
      {error && <div className="error">{error}</div>}
      <div className="panel">
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th /></tr></thead>
          <tbody>
            {users.map((u) => {
              const self = u.id === me.id;
              return (
                <tr key={u.id}>
                  <td>{u.name}{self && <span className="muted small"> (you)</span>}</td>
                  <td>{u.email}</td>
                  <td>
                    <select value={u.role} disabled={self} aria-label={`Role for ${u.name}`}
                            onChange={(e) => act(() => api.updateUser(u.id, { role: e.target.value as Role }))}>
                      {ROLES.map((r) => <option key={r}>{r}</option>)}
                    </select>
                  </td>
                  <td><span className={`badge ${u.status === "active" ? "approved" : "rejected"}`}>{u.status}</span></td>
                  <td>
                    <div className="actions">
                      {!self && (
                        <button className="small" onClick={() => act(() =>
                          api.updateUser(u.id, { status: u.status === "active" ? "suspended" : "active" }))}>
                          {u.status === "active" ? "Suspend" : "Reactivate"}
                        </button>
                      )}
                      <button className="small" onClick={() => setResetFor(u)}>Reset password</button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {creating && (
        <Modal title="New user" onClose={() => setCreating(false)}>
          <form onSubmit={create}>
            <label htmlFor="un">Name</label>
            <input id="un" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            <label htmlFor="ue">Email</label>
            <input id="ue" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
            <label htmlFor="ur">Role</label>
            <select id="ur" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as Role })}>
              {ROLES.map((r) => <option key={r}>{r}</option>)}
            </select>
            <label htmlFor="up">Temporary password (min 8 characters)</label>
            <input id="up" type="password" minLength={8} value={form.password}
                   onChange={(e) => setForm({ ...form, password: e.target.value })} required />
            <button>Create user</button>
          </form>
        </Modal>
      )}
      {resetFor && (
        <Modal title={`Reset password: ${resetFor.name}`} onClose={() => setResetFor(null)}>
          <form onSubmit={reset}>
            <label htmlFor="np">New password (min 8 characters)</label>
            <input id="np" type="password" minLength={8} value={newPw} onChange={(e) => setNewPw(e.target.value)} required autoFocus />
            <button>Set password</button>
          </form>
        </Modal>
      )}
    </>
  );
}

export default function Page() { return <Shell><Inner /></Shell>; }
