"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import Shell, { useUser } from "@/components/Shell";
import { api, Stats } from "@/lib/api";

function Card({ label, value }: { label: string; value: number }) {
  return <div className="card"><div className="muted small">{label}</div><div className="num">{value}</div></div>;
}

function Inner() {
  const user = useUser();
  const [s, setS] = useState<Stats | null>(null);
  useEffect(() => { api.stats().then(setS).catch(() => {}); }, []);
  const total = s ? Object.values(s.cases).reduce((a, b) => a + b, 0) : 0;
  const canReview = user.role === "reviewer" || user.role === "admin";

  return (
    <>
      <h1>Welcome, {user.name}</h1>
      <div className="cards">
        <Card label="Total cases" value={total} />
        <Card label="Pending approval" value={s?.cases.pending_approval ?? 0} />
        <Card label="Approved" value={s?.cases.approved ?? 0} />
        <Card label="Searches run" value={s?.searches ?? 0} />
        <Card label="Awaiting review" value={s?.pending_review ?? 0} />
      </div>
      <div className="cards">
        <Card label="Confirmed leads" value={s?.decisions.confirmed ?? 0} />
        <Card label="Rejected" value={s?.decisions.rejected ?? 0} />
        <Card label="Inconclusive" value={s?.decisions.inconclusive ?? 0} />
      </div>
      {canReview && (s?.pending_review ?? 0) > 0 && (
        <div className="panel"><Link href="/reviews">{s?.pending_review} candidate(s) awaiting independent review →</Link></div>
      )}
    </>
  );
}

export default function Page() { return <Shell><Inner /></Shell>; }
