"use client";
import Link from "next/link";
import { FormEvent, useCallback, useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Shell, { useUser } from "@/components/Shell";
import { CandImage, RefImage } from "@/components/Thumbs";
import Modal from "@/components/Modal";
import { api, Case, Note, ReferenceImage, SearchResult } from "@/lib/api";

function Inner() {
  const user = useUser();
  const caseId = Number(useParams<{ id: string }>().id);
  const [c, setCase] = useState<Case | null>(null);
  const [images, setImages] = useState<ReferenceImage[]>([]);
  const [searches, setSearches] = useState<SearchResult[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [noteText, setNoteText] = useState("");
  const [searching, setSearching] = useState<number | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [source, setSource] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [retOpen, setRetOpen] = useState(false);
  const [retDate, setRetDate] = useState("");
  const canWrite = user.role === "investigator" || user.role === "admin";
  const canNote = canWrite || user.role === "reviewer";

  const load = useCallback(() => {
    api.case(caseId).then(setCase).catch((e) => setError(e.message));
    api.referenceImages(caseId).then(setImages).catch(() => {});
    api.searches(caseId).then(setSearches).catch(() => {});
    api.notes(caseId).then(setNotes).catch(() => {});
  }, [caseId]);
  useEffect(load, [load]);

  async function upload(e: FormEvent) {
    e.preventDefault();
    if (!file) return;
    setBusy(true); setError("");
    try {
      await api.uploadReference(caseId, file, source);
      setFile(null); setSource(""); (e.target as HTMLFormElement).reset(); load();
    } catch (err) { setError(err instanceof Error ? err.message : "Upload failed"); }
    finally { setBusy(false); }
  }

  async function runSearch(imageId: number) {
    setSearching(imageId); setError("");
    try { await api.runSearch(caseId, imageId); load(); }
    catch (err) { setError(err instanceof Error ? err.message : "Search failed"); }
    finally { setSearching(null); }
  }

  async function remove(id: number) {
    if (!window.confirm("Permanently delete this image?")) return;
    try { await api.deleteReference(id); load(); }
    catch (err) { setError(err instanceof Error ? err.message : "Delete failed"); }
  }

  async function lifecycle(fn: () => Promise<unknown>) {
    setError("");
    try { await fn(); load(); } catch (err) { setError(err instanceof Error ? err.message : "Failed"); }
  }

  async function saveRetention(e: FormEvent) {
    e.preventDefault();
    await lifecycle(async () => { await api.setRetention(caseId, new Date(retDate).toISOString()); setRetOpen(false); });
  }

  async function addNote(e: FormEvent) {
    e.preventDefault();
    try { await api.addNote(caseId, noteText); setNoteText(""); load(); }
    catch (err) { setError(err instanceof Error ? err.message : "Could not add note"); }
  }

  if (!c) return error ? <div className="error">{error}</div> : <div className="muted">Loading…</div>;
  return (
    <>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1>{c.case_ref}</h1>
        <Link href={`/cases/${caseId}/report`}>View report →</Link>
      </div>
      <div className="panel" style={{ marginBottom: 20 }}>
        <div className="muted small">Purpose</div>
        <div>{c.purpose}</div>
        <div className="actions" style={{ marginTop: 10 }}>
          <span className={`badge ${c.status}`}>{c.status.replace("_", " ")}</span>
          <span className="muted small">Retain until {new Date(c.retention_date).toLocaleDateString()}</span>
          {user.role === "admin" && <button className="small" onClick={() => setRetOpen(true)}>Change retention</button>}
          {canWrite && c.status !== "closed" && (
            <button className="small" onClick={() => window.confirm("Close this case? Uploads, searches and reviews will be locked.") && lifecycle(() => api.closeCase(caseId))}>Close case</button>
          )}
          {user.role === "admin" && c.status === "closed" && (
            <button className="small" onClick={() => lifecycle(() => api.reopenCase(caseId))}>Reopen case</button>
          )}
        </div>
      </div>
      {error && <div className="error">{error}</div>}

      <h2 style={{ fontSize: 16 }}>Reference images</h2>
      {canWrite && c.status === "approved" && (
        <form className="panel" onSubmit={upload} style={{ marginBottom: 16 }}>
          <label htmlFor="src">Image source (required)</label>
          <input id="src" value={source} onChange={(e) => setSource(e.target.value)} required
                 placeholder="e.g. synthetic test image / consented volunteer" />
          <label htmlFor="file">Image (JPEG or PNG, max 5 MB, one clear frontal face)</label>
          <input id="file" type="file" accept="image/jpeg,image/png" required
                 onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
          <button disabled={busy || !file}>{busy ? "Checking…" : "Upload and check quality"}</button>
        </form>
      )}
      {canWrite && c.status !== "approved" && (
        <div className="panel muted" style={{ marginBottom: 16 }}>Uploads are enabled once an administrator approves this case.</div>
      )}
      <div className="thumbs">
        {images.map((im) => (
          <div className="panel" key={im.id}>
            <RefImage id={im.id} />
            <div className="small" style={{ marginTop: 8 }}>{im.source}</div>
            <div className="muted small">
              Face {im.quality.metrics.face_px}px · sharpness {im.quality.metrics.blur_score} · brightness {im.quality.metrics.brightness}
            </div>
            {canWrite && (
              <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                <button className="small" disabled={searching === im.id || c.status !== "approved"}
                        onClick={() => runSearch(im.id)}>{searching === im.id ? "Searching…" : "Search gallery"}</button>
                <button className="small" onClick={() => remove(im.id)}>Delete</button>
              </div>
            )}
          </div>
        ))}
        {images.length === 0 && <div className="muted">No reference images yet.</div>}
      </div>

      <h2 style={{ fontSize: 16, marginTop: 28 }}>Gallery searches</h2>
      {searches.length === 0 && <div className="muted">No searches run yet.</div>}
      {searches.slice(0, 5).map((sr) => (
        <div className="panel" key={sr.id} style={{ marginBottom: 16 }}>
          <div>Search #{sr.id} · reference image #{sr.reference_image_id} · {new Date(sr.created_at).toLocaleString()}</div>
          <div className="muted small">Gallery size {sr.gallery_size} · threshold {sr.threshold} · model {sr.model_version}</div>
          {sr.outcome === "no_match" ? (
            <div style={{ margin: "12px 0" }}>
              <strong>No candidates above the threshold.</strong>
              <div className="muted small">This does not prove the person is absent from the gallery or elsewhere.</div>
            </div>
          ) : (
            <div className="thumbs" style={{ margin: "12px 0" }}>
              {sr.candidates.map((cd) => (
                <div className="panel" key={cd.id}>
                  <CandImage id={cd.id} />
                  <div style={{ marginTop: 8 }}>#{cd.rank} · similarity {cd.score.toFixed(3)}</div>
                  <div className="small">{cd.source}</div>
                  <span className={`badge ${cd.review_status}`}>
                    {cd.review_status === "pending" ? "Awaiting human review" : cd.review_status}
                  </span>
                </div>
              ))}
            </div>
          )}
          <div className="muted small">{sr.notice}</div>
        </div>
      ))}

      {retOpen && (
        <Modal title="Change retention date" onClose={() => setRetOpen(false)}>
          <form onSubmit={saveRetention}>
            <label htmlFor="rd">New retention date (must be in the future)</label>
            <input id="rd" type="date" value={retDate} onChange={(e) => setRetDate(e.target.value)} required autoFocus />
            <button>Save</button>
          </form>
        </Modal>
      )}

      <h2 style={{ fontSize: 16, marginTop: 28 }}>Case notes</h2>
      {canNote && (
        <form className="panel" onSubmit={addNote} style={{ marginBottom: 12 }}>
          <textarea rows={2} value={noteText} onChange={(e) => setNoteText(e.target.value)} placeholder="Add a note…" required />
          <button disabled={!noteText.trim()}>Add note</button>
        </form>
      )}
      {notes.map((n) => (
        <div className="panel" key={n.id} style={{ marginBottom: 8 }}>
          {n.body}
          <div className="muted small">{n.author_name} · {new Date(n.created_at).toLocaleString()}</div>
        </div>
      ))}
      {notes.length === 0 && <div className="muted">No notes yet.</div>}
    </>
  );
}

export default function Page() { return <Shell><Inner /></Shell>; }
