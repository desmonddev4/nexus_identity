"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import Shell from "@/components/Shell";
import { api, ReportData } from "@/lib/api";

const fmt = (d: string) => new Date(d).toLocaleString();

function Inner() {
  const caseId = Number(useParams<{ id: string }>().id);
  const [r, setR] = useState<ReportData | null>(null);
  const [error, setError] = useState("");
  useEffect(() => { api.report(caseId).then(setR).catch((e) => setError(e.message)); }, [caseId]);

  if (error) return <div className="error">{error}</div>;
  if (!r) return <div className="muted">Loading…</div>;
  return (
    <div className="report">
      <div className="noprint" style={{ display: "flex", gap: 12, alignItems: "center" }}>
        <Link href={`/cases/${caseId}`}>← Back to case</Link>
        <button onClick={() => window.print()} style={{ margin: 0 }}>Print / save as PDF</button>
      </div>
      <h1>Case report: {r.case.case_ref}</h1>
      <div className="muted small">Generated {fmt(r.generated_at)} by {r.generated_by}</div>
      <div className="panel" style={{ margin: "12px 0" }}>{r.disclaimer}</div>

      <h2>Case</h2>
      <div className="panel">
        <div>{r.case.purpose}</div>
        <div className="muted small">Status {r.case.status} · owner {r.case.owner} · retain until {new Date(r.case.retention_date).toLocaleDateString()} · {r.reference_images} reference image(s)</div>
      </div>

      <h2>Approvals</h2>
      {r.authorizations.length === 0 && <div className="muted">None</div>}
      {r.authorizations.map((a, i) => (
        <div key={i} className="panel">{a.scope} — approved by {a.approved_by}, expires {fmt(a.expires_at)}</div>
      ))}

      <h2>Searches and review decisions</h2>
      {r.searches.length === 0 && <div className="muted">No searches run.</div>}
      {r.searches.map((s) => (
        <div key={s.id} className="panel" style={{ marginBottom: 12 }}>
          <strong>Search #{s.id}</strong> · {fmt(s.created_at)} · run by {s.requested_by}
          <div className="muted small">Outcome: {s.outcome.replace("_", " ")} · gallery {s.gallery_size} · threshold {s.threshold} · {s.model_version}</div>
          {s.candidates.map((c) => (
            <div key={c.rank} style={{ marginTop: 10 }}>
              #{c.rank} · similarity {c.score.toFixed(3)} · {c.source} · <span className={`badge ${c.review_status}`}>{c.review_status}</span>
              {c.decisions.map((d, i) => (
                <div key={i} className="muted small" style={{ marginLeft: 16 }}>
                  {fmt(d.at)} — {d.reviewer}: {d.decision} — {d.reason}
                </div>
              ))}
            </div>
          ))}
        </div>
      ))}

      <h2>Case notes</h2>
      {r.notes.length === 0 && <div className="muted">None</div>}
      {r.notes.map((n, i) => <div key={i} className="panel" style={{ marginBottom: 8 }}>{n.body}<div className="muted small">{n.author} · {fmt(n.created_at)}</div></div>)}

      <h2>Audit trail</h2>
      <div className="panel">
        <table>
          <thead><tr><th>Time</th><th>Action</th><th>Actor</th><th>Detail</th></tr></thead>
          <tbody>{r.audit.map((e, i) => (
            <tr key={i}><td>{fmt(e.timestamp)}</td><td>{e.action}</td><td>{e.actor}</td><td className="muted">{e.detail ?? ""}</td></tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}

export default function Page() { return <Shell><Inner /></Shell>; }
