"use client";
import Link from "next/link";
import { FormEvent, useCallback, useEffect, useState } from "react";
import Shell, { useUser } from "@/components/Shell";
import Modal from "@/components/Modal";
import { api, Case } from "@/lib/api";

function Inner() {
  const user = useUser();
  const [cases, setCases] = useState<Case[]>([]);
  const [error, setError] = useState("");
  const [ref, setRef] = useState("");
  const [purpose, setPurpose] = useState("");
  const [retention, setRetention] = useState("");
  const [approving, setApproving] = useState<Case | null>(null);
  const [scope, setScope] = useState("");
  const [days, setDays] = useState("30");
  const canCreate = user.role === "investigator" || user.role === "admin";

  const load = useCallback(() => { api.cases().then(setCases).catch((e) => setError(e.message)); }, []);
  useEffect(load, [load]);

  async function create(e: FormEvent) {
    e.preventDefault(); setError("");
    try {
      await api.createCase({ case_ref: ref, purpose, retention_date: new Date(retention).toISOString() });
      setRef(""); setPurpose(""); setRetention(""); load();
    } catch (err) { setError(err instanceof Error ? err.message : "Failed"); }
  }

  async function approve(e: FormEvent) {
    e.preventDefault();
    if (!approving) return;
    try {
      await api.approveCase(approving.id, {
        scope, expires_at: new Date(Date.now() + Number(days) * 864e5).toISOString(),
      });
      setApproving(null); setScope(""); setDays("30"); load();
    } catch (err) { setError(err instanceof Error ? err.message : "Failed"); setApproving(null); }
  }

  return (
    <>
      <h1>Cases</h1>
      {error && <div className="error">{error}</div>}
      {canCreate && (
        <form className="panel" onSubmit={create} style={{ marginBottom: 20 }}>
          <strong>New case</strong>
          <div className="row">
            <div><label htmlFor="ref">Case reference</label><input id="ref" value={ref} onChange={(e) => setRef(e.target.value)} required /></div>
            <div><label htmlFor="ret">Retention deadline</label><input id="ret" type="date" value={retention} onChange={(e) => setRetention(e.target.value)} required /></div>
          </div>
          <label htmlFor="purpose">Documented purpose</label>
          <textarea id="purpose" rows={2} value={purpose} onChange={(e) => setPurpose(e.target.value)} required />
          <button>Create case</button>
        </form>
      )}
      <div className="panel">
        <table>
          <thead><tr><th>Reference</th><th>Purpose</th><th>Status</th><th>Retain until</th><th /></tr></thead>
          <tbody>
            {cases.map((c) => (
              <tr key={c.id}>
                <td><Link href={`/cases/${c.id}`}>{c.case_ref}</Link></td>
                <td>{c.purpose}</td>
                <td><span className={`badge ${c.status}`}>{c.status.replace("_", " ")}</span></td>
                <td>{new Date(c.retention_date).toLocaleDateString()}</td>
                <td>{user.role === "admin" && c.status === "pending_approval" &&
                  <button className="small" onClick={() => setApproving(c)}>Approve</button>}</td>
              </tr>
            ))}
            {cases.length === 0 && <tr><td colSpan={5} className="muted">No cases yet.</td></tr>}
          </tbody>
        </table>
      </div>

      {approving && (
        <Modal title={`Approve ${approving.case_ref}`} onClose={() => setApproving(null)}>
          <div className="muted small" style={{ marginTop: 8 }}>{approving.purpose}</div>
          <form onSubmit={approve}>
            <label htmlFor="scope">Scope of approval</label>
            <input id="scope" value={scope} onChange={(e) => setScope(e.target.value)} required
                   placeholder="e.g. authorized test gallery only" autoFocus />
            <label htmlFor="days">Valid for (days)</label>
            <input id="days" type="number" min={1} max={365} value={days} onChange={(e) => setDays(e.target.value)} required />
            <button>Approve case</button>
          </form>
        </Modal>
      )}
    </>
  );
}

export default function Page() { return <Shell><Inner /></Shell>; }
