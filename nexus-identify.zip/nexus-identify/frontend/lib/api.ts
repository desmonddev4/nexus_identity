// NOTE: token is kept in sessionStorage for the prototype (cleared when the tab closes).
// TODO: move to an httpOnly cookie session before any real deployment.

export type Role = "admin" | "investigator" | "reviewer" | "auditor";

export interface User { id: number; name: string; email: string; role: Role; status: string }
export interface Case {
  id: number; case_ref: string; purpose: string; status: string;
  owner_id: number; retention_date: string;
}
export interface ReferenceImage {
  id: number; case_id: number; source: string; sha256: string;
  quality: { usable: boolean; reasons: string[]; metrics: Record<string, number> };
  status: string; created_at: string;
}
export interface CandidateItem {
  id: number; rank: number; gallery_record_id: number; score: number; source: string; review_status: string;
}
export interface SearchResult {
  id: number; case_id: number; reference_image_id: number; outcome: "candidates" | "no_match";
  model_version: string; threshold: number; gallery_size: number; created_at: string;
  candidates: CandidateItem[]; notice: string;
}
export type DecisionValue = "confirmed" | "rejected" | "inconclusive";
export interface Decision {
  id: number; candidate_id: number; reviewer_id: number; reviewer_name: string;
  decision: DecisionValue; reason: string; created_at: string; warning: string | null;
}
export interface QueueItem {
  candidate_id: number; rank: number; score: number; source: string; case_id: number;
  case_ref: string; search_id: number; reference_image_id: number; created_at: string;
}
export interface Note { id: number; author_id: number; author_name: string; body: string; created_at: string }
export interface Stats {
  cases: Record<string, number>; searches: number; pending_review: number; decisions: Record<string, number>;
}
export interface ReportData {
  generated_at: string; generated_by: string;
  case: { case_ref: string; purpose: string; status: string; owner: string; retention_date: string; created_at: string };
  authorizations: { approved_by: string; scope: string; expires_at: string }[];
  reference_images: number;
  searches: {
    id: number; created_at: string; requested_by: string; outcome: string; model_version: string;
    threshold: number; gallery_size: number;
    candidates: { rank: number; score: number; source: string; review_status: string;
      decisions: { reviewer: string; decision: string; reason: string; at: string }[] }[];
  }[];
  notes: { author: string; body: string; created_at: string }[];
  audit: { timestamp: string; action: string; actor: string; detail: string | null }[];
  disclaimer: string;
}
export interface GalleryItem {
  id: number; source: string; permission_basis: string; sha256: string; status: string;
  collected_at: string; delete_after: string;
  quality: { metrics: Record<string, number> };
}
export interface AuditEvent {
  id: number; actor_id: number | null; action: string;
  case_id: number | null; detail: string | null; timestamp: string;
}

const KEY = "nexus_token";
export const getToken = () => (typeof window === "undefined" ? null : sessionStorage.getItem(KEY));
export const setToken = (t: string) => sessionStorage.setItem(KEY, t);
export const clearToken = () => sessionStorage.removeItem(KEY);

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  const token = getToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  const res = await fetch(`/api${path}`, { ...init, headers });
  if (!res.ok) {
    let msg = res.statusText;
    try {
      const body = await res.json();
      const d = body.detail;
      msg = typeof d === "string" ? d
        : d?.reasons ? `Image rejected: ${d.reasons.map((r: string) => r.replace(/_/g, " ")).join(", ")}`
        : JSON.stringify(d);
    } catch { /* ignore */ }
    throw new ApiError(res.status, msg);
  }
  return res.json() as Promise<T>;
}

export async function login(email: string, password: string) {
  const res = await request<{ access_token: string }>("/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ username: email, password }),
  });
  setToken(res.access_token);
}

const json = (body: unknown): RequestInit => ({
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body),
});

export const api = {
  me: () => request<User>("/auth/me"),
  cases: () => request<Case[]>("/cases"),
  createCase: (b: { case_ref: string; purpose: string; retention_date: string }) =>
    request<Case>("/cases", json(b)),
  approveCase: (id: number, b: { scope: string; expires_at: string }) =>
    request<Case>(`/cases/${id}/approve`, json(b)),
  audit: () => request<AuditEvent[]>("/audit"),
  runSearch: (caseId: number, referenceImageId: number) =>
    request<SearchResult>(`/cases/${caseId}/searches`, json({ reference_image_id: referenceImageId })),
  searches: (caseId: number) => request<SearchResult[]>(`/cases/${caseId}/searches`),
  candidateBlobUrl: async (id: number) => {
    const res = await fetch(`/api/candidates/${id}/image`, { headers: { Authorization: `Bearer ${getToken()}` } });
    if (!res.ok) throw new ApiError(res.status, "Could not load image");
    return URL.createObjectURL(await res.blob());
  },
  stats: () => request<Stats>("/stats"),
  reviewQueue: () => request<QueueItem[]>("/reviews/pending"),
  decide: (candidateId: number, decision: DecisionValue, reason: string) =>
    request<Decision>(`/candidates/${candidateId}/decisions`, json({ decision, reason })),
  notes: (caseId: number) => request<Note[]>(`/cases/${caseId}/notes`),
  addNote: (caseId: number, body: string) => request<Note>(`/cases/${caseId}/notes`, json({ body })),
  report: (caseId: number) => request<ReportData>(`/cases/${caseId}/report`),
  users: () => request<User[]>("/auth/users"),
  createUser: (b: { name: string; email: string; password: string; role: Role }) =>
    request<User>("/auth/users", json(b)),
  updateUser: (id: number, b: { role?: Role; status?: string; password?: string }) =>
    request<User>(`/auth/users/${id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b),
    }),
  closeCase: (id: number) => request<Case>(`/cases/${id}/close`, { method: "POST" }),
  reopenCase: (id: number) => request<Case>(`/cases/${id}/reopen`, { method: "POST" }),
  setRetention: (id: number, iso: string) => request<Case>(`/cases/${id}/retention`, json({ retention_date: iso })),
  gallery: () => request<GalleryItem[]>("/gallery"),
  addGallery: (f: { file: File; source: string; basis: string; deleteAfter: string }) => {
    const fd = new FormData();
    fd.append("source", f.source);
    fd.append("permission_basis", f.basis);
    fd.append("delete_after", f.deleteAfter);
    fd.append("file", f.file);
    return request<GalleryItem>("/gallery", { method: "POST", body: fd });
  },
  deleteGallery: (id: number) => request<{ ok: boolean }>(`/gallery/${id}`, { method: "DELETE" }),
  galleryBlobUrl: async (id: number) => {
    const res = await fetch(`/api/gallery/${id}/image`, { headers: { Authorization: `Bearer ${getToken()}` } });
    if (!res.ok) throw new ApiError(res.status, "Could not load image");
    return URL.createObjectURL(await res.blob());
  },
  case: (id: number) => request<Case>(`/cases/${id}`),
  referenceImages: (caseId: number) => request<ReferenceImage[]>(`/cases/${caseId}/reference-images`),
  uploadReference: (caseId: number, file: File, source: string) => {
    const fd = new FormData();
    fd.append("source", source);
    fd.append("file", file);
    return request<ReferenceImage>(`/cases/${caseId}/reference-images`, { method: "POST", body: fd });
  },
  deleteReference: (id: number) => request<{ ok: boolean }>(`/reference-images/${id}`, { method: "DELETE" }),
  referenceBlobUrl: async (id: number) => {
    const res = await fetch(`/api/reference-images/${id}/file`, {
      headers: { Authorization: `Bearer ${getToken()}` },
    });
    if (!res.ok) throw new ApiError(res.status, "Could not load image");
    return URL.createObjectURL(await res.blob());
  },
};
