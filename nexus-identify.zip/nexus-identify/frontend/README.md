# Nexus Identify — frontend (Next.js 14 + TypeScript)

    npm install
    npm run dev        # http://localhost:3000

Requests to /api/* are proxied to the FastAPI backend (default http://localhost:8000;
override with BACKEND_URL). Start the backend first and create an admin with `python -m app.seed`.
