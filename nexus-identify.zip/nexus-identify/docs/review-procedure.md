# Human review procedure (DRAFT — to be agreed with the partner agency)

1. A search produces *possible* matches ranked by similarity, or "no match". Nothing is identified.
2. **Independent review:** the person who ran a search cannot review its results. Only reviewers
   (or administrators who did not run the search) can record decisions.
3. Each decision is `confirmed`, `rejected` or `inconclusive`, with a written reason (≥ 10 chars).
   History is kept; the latest decision sets the candidate's status.
4. `confirmed` means "worth investigating further" — **not** an identification and **never** grounds
   for arrest, accusation or adverse action by itself. The system displays this warning on every confirmation.
5. Reviews require an unexpired case approval.
6. Auditors can see decisions, notes and audit events (via the case report) but never images.
7. Disputed or mistaken results: add a case note and record a new decision; history stays intact.
   A formal correction/appeals procedure is still to be defined with the agency.
8. Case reports contain no images or biometric data and carry a standing disclaimer.
