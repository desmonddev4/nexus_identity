# Nexus Identify — Requirements (DRAFT)

## Purpose
Help authorized investigators compare a reference photo against an approved image gallery and manage leads for human review. The system never declares an identity; it returns ranked *possible* matches or "no match".

## Authorized users
Admin, investigator, reviewer, auditor. Nexus Sync developers: no access to operational data.

## In scope (v1)
Accounts and roles, case management, authorized gallery, similarity matching, human review, audit log, retention/deletion.

## Out of scope / prohibited
- Scraping or automated collection from social media platforms
- Using a match score alone as grounds for arrest, accusation or adverse action
- Processing real people's images without documented lawful basis and approval
- Any gallery source without recorded permission

## Success criteria
To be agreed with the prospective agency and independent reviewers after testing. No accuracy claims before measured results.

## Open questions
- Lawful basis and DPC registration (Act 843)
- Choice of recognition model and licence
- Hosting location and retention periods
