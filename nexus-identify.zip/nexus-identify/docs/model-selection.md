# Recognition model selection (Phase 4)

## Current choice
OpenCV Zoo **YuNet** (face detection, `face_detection_yunet_2023mar.onnx`) + **SFace**
(recognition, `face_recognition_sface_2021dec.onnx`, 128-d embeddings), run through OpenCV
(`cv2.FaceDetectorYN` / `cv2.FaceRecognizerSF`). No extra ML runtime or GPU required.

## Licence position (verified from public sources, October 2026)
- OpenCV Zoo repository: Apache-2.0 (commercial use permitted).
- SFace weights are converted from the SFace research model (github.com/zhongyy/SFace).
  **Open item:** the Apache-2.0 repo licence does not by itself settle the provenance of the
  *training dataset*. Have counsel confirm before any government pilot.
- Some other popular pretrained packs (e.g. InsightFace "buffalo" models) are reported as
  non-commercial / research-only. Do not switch to them without checking their licence.

## Caveats
- `match_threshold = 0.363` (cosine) is the value used in OpenCV's SFace demo. It is **not**
  validated on our data or population. Phase 6 must measure FPR/FNR and set the threshold with
  the agency and independent reviewers — not to make demos look good.
- Accuracy across demographic groups is unmeasured. Do not claim fairness until tested.
- Embeddings from different models are not comparable; every embedding stores `model_version`.

## Pinned files (fill in after running scripts/download_models.py)
| File | SHA-256 |
| ---- | ------- |
| face_detection_yunet_2023mar.onnx | _TBD_ |
| face_recognition_sface_2021dec.onnx | _TBD_ |

## Design decisions
- Embeddings are stored **encrypted** (Fernet) in PostgreSQL and searched by brute force in
  memory. Fine for a prototype gallery (thousands). pgvector can't search encrypted vectors;
  revisit with an explicit threat model if the gallery grows.
- The reference image's embedding is computed in memory per search and never stored.
