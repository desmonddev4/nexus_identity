# Nexus Identify
AI-assisted identity investigation prototype by Nexus Sync Technologies. Authorized galleries only; human review required.

## Run
    cp .env.example .env     # then set STORAGE_ENCRYPTION_KEY (command shown in the file)
    docker compose up --build
    docker compose exec backend python -m app.seed you@example.com "Your Name" "strong-password"
Download recognition models (once): `docker compose exec backend python scripts/download_models.py`
API docs: http://localhost:8000/docs

## Test (no Docker)
    cd backend && pip install -r requirements.txt && pytest

See TODO.md for progress and docs/requirements.md for scope.
